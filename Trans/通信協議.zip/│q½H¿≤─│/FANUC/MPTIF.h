/*-------------------------------------- struct define -------------------------------------------*/
typedef struct  _CURRENTDATAS
{
    DWORD         dwDataID;               // 0  DataID
    double        dData;                // 4  Cond     
    double        dMax ;                    // 12 Max
    double        dMin ;                    // 20 Min
    WORD          wReturn ;                 // 28 Result
    BYTE          btSpare[18] ;             // 30 Spare

} CURRENTDATAS, *PCURRENTDATAS;             // 48

typedef struct  _ACSCURRENTDATAS
{
    DWORD               dwCount ;           // 0 Data Count
    PCURRENTDATAS       ptypeCurrentDatas ; // 4 Pointer to Set/Get Data
    BYTE                bSpare[8] ;         // 8 Spare

} ACSCURRENTDATAS, *PACSCURRENTDATAS;       // 16 

extern  "C" 
{
    short    WINAPI  MPTIF_Init_SA           (BYTE btIp1, BYTE btIp2, BYTE btIp3, BYTE btIp4, WORD wTimeout, WORD* pwHandle, WORD* pwVersion = NULL);
    short    WINAPI  MPTIF_Finish_SA         (WORD wHandle, BYTE btIp1 = 0, BYTE btIp2 = 0, BYTE btIp3 = 0, BYTE btIp4 = 0);
    short    WINAPI  MPTIF_GetCurrentMI_SA   (WORD wHandle, WORD* pwMcType, BYTE* pbtUnit, BYTE btIp1 = 0, BYTE btIp2 = 0, BYTE btIp3 = 0, BYTE btIp4 = 0);
    short    WINAPI  MPTIF_LockScr_SA        (WORD wHandle, BYTE btIp1 = 0, BYTE btIp2 = 0, BYTE btIp3 = 0, BYTE btIp4 = 0);
    short    WINAPI  MPTIF_UnlockScr_SA      (WORD wHandle, BYTE btIp1 = 0, BYTE btIp2 = 0, BYTE btIp3 = 0, BYTE btIp4 = 0);
    short    WINAPI  MPTIF_GetCurrentMP_SA   (WORD wHandle, DWORD dwDataID, double* pdData, double* pdMax, double* pdMin, WORD* pwResult, WORD wTimeout, BYTE btIp1 = 0, BYTE btIp2 = 0, BYTE btIp3 = 0, BYTE btIp4 = 0);
    short    WINAPI  MPTIF_SetCurrentMP_SA   (WORD wHandle, DWORD dwDataID, double dData, WORD* pwResult, WORD wTimeout, BOOL bIgnoreInputLock, BYTE btIp1 = 0, BYTE btIp2 = 0, BYTE btIp3 = 0, BYTE btIp4 = 0);
    short    WINAPI  MPTIF_GetCurrentMonit_SA(WORD wHandle, DWORD dwDataID, double* pdData, WORD* pwResult, WORD wTimeout, BYTE btIp1 = 0, BYTE btIp2 = 0, BYTE btIp3 = 0, BYTE btIp4 = 0);
    short    WINAPI  MPTIF_GetCurrentMP_Plural_SA(WORD wHandle, PACSCURRENTDATAS   ptypeGetCurrentDatas, WORD wTimeout, WORD wVersion = 0, BYTE btIp1 = 0, BYTE btIp2 = 0, BYTE btIp3 = 0, BYTE btIp4 = 0);
    short    WINAPI  MPTIF_SetCurrentMP_Plural_SA(WORD wHandle, PACSCURRENTDATAS   ptypeSetCurrentDatas, WORD wTimeout, BOOL bIgnoreInputLock, WORD wVersion = 0, BYTE btIp1 = 0, BYTE btIp2 = 0, BYTE btIp3 = 0, BYTE btIp4 = 0);

    short    WINAPI  MPTIF_Init_SB           (BYTE btIp1, BYTE btIp2, BYTE btIp3, BYTE btIp4, WORD wTimeout, WORD* pwHandle, WORD* pwVersion = NULL);
    short    WINAPI  MPTIF_Finish_SB         (WORD wHandle, BYTE btIp1 = 0, BYTE btIp2 = 0, BYTE btIp3 = 0, BYTE btIp4 = 0);
    short    WINAPI  MPTIF_GetCurrentMI_SB   (WORD wHandle, WORD* pwMcType, BYTE* pbtUnit, BYTE btIp1 = 0, BYTE btIp2 = 0, BYTE btIp3 = 0, BYTE btIp4 = 0);
    short    WINAPI  MPTIF_LockScr_SB        (WORD wHandle, BYTE btIp1 = 0, BYTE btIp2 = 0, BYTE btIp3 = 0, BYTE btIp4 = 0);
    short    WINAPI  MPTIF_UnlockScr_SB      (WORD wHandle, BYTE btIp1 = 0, BYTE btIp2 = 0, BYTE btIp3 = 0, BYTE btIp4 = 0);
    short    WINAPI  MPTIF_GetCurrentMP_SB   (WORD wHandle, DWORD dwDataID, double* pdData, double* pdMax, double* pdMin, WORD* pwResult, WORD wTimeout, BYTE btIp1 = 0, BYTE btIp2 = 0, BYTE btIp3 = 0, BYTE btIp4 = 0);
    short    WINAPI  MPTIF_SetCurrentMP_SB   (WORD wHandle, DWORD dwDataID, double dData, WORD* pwResult, WORD wTimeout, BOOL bIgnoreInputLock, BYTE btIp1 = 0, BYTE btIp2 = 0, BYTE btIp3 = 0, BYTE btIp4 = 0);
    short    WINAPI  MPTIF_GetCurrentMonit_SB(WORD wHandle, DWORD dwDataID, double* pdData, WORD* pwResult, WORD wTimeout, BYTE btIp1 = 0, BYTE btIp2 = 0, BYTE btIp3 = 0, BYTE btIp4 = 0);
    short    WINAPI  MPTIF_GetCurrentMP_Plural_SB(WORD wHandle, PACSCURRENTDATAS   ptypeGetCurrentDatas, WORD wTimeout, WORD wVersion = 0, BYTE btIp1 = 0, BYTE btIp2 = 0, BYTE btIp3 = 0, BYTE btIp4 = 0);
    short    WINAPI  MPTIF_SetCurrentMP_Plural_SB(WORD wHandle, PACSCURRENTDATAS   ptypeSetCurrentDatas, WORD wTimeout, BOOL bIgnoreInputLock, WORD wVersion = 0, BYTE btIp1 = 0, BYTE btIp2 = 0, BYTE btIp3 = 0, BYTE btIp4 = 0);
}
