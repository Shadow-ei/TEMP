﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using RabbitMQ;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using Newtonsoft;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json.Converters;
using System.Threading;
using System.Messaging;

namespace ca9
{

    //======================工單數據傳輸 =========
    class OrderDataJson
    {
        public Int32 IDcount = 0; //累計不重複發送數據標誌
        public void sendOrderData()
        {
            while (true)
            {
                //數據庫連接
                SqlConnectionStringBuilder sconnsb = new SqlConnectionStringBuilder();
                sconnsb.DataSource = DataBase.DataSource;
                sconnsb.InitialCatalog = DataBase.InitialCatalog;
                sconnsb.UserID = DataBase.UserID;
                sconnsb.Password = DataBase.Password;
                sconnsb.MultipleActiveResultSets = true;
                SqlConnection sconn = new SqlConnection(sconnsb.ToString());
                try
                {
                    //起始時間確定，每天早上7:50
                    DateTime dtn = DateTime.Now;    //當前時間
                    DateTime dtns = new DateTime(); //起始日期
                    string dtn1 = ""; //起始時間
                    int dtny = dtn.Year;
                    int dtnm = dtn.Month;
                    int dtnd = dtn.Day;

                    string dtnStr = dtn.ToString("yyyyMMddHHmmss");
                    long dtnl = long.Parse(dtnStr);
                    long dtnSl = long.Parse(dtn.ToString("yyyyMMdd") + "075000");

                    if (dtnl >= dtnSl)
                    {
                        dtns = dtn;//後一天時間
                    }
                    else
                    {
                        dtns = dtn.AddDays(-1);//前一天時間
                    }

                    dtn1 = dtns.ToString("yyyyMMdd") + "075000";
                    long dtnc1 = long.Parse(dtn1);

                    sconn.Open();
                    //獲取機台數量
                    string sql = "SELECT COUNT(*) FROM [M4_DATABASE].[dbo].[BASIC_INFORMATION] ";
                    SqlCommand cmd = new SqlCommand(sql, sconn);
                    object obj = cmd.ExecuteScalar();
                    cmd.Dispose();

                    string mc = obj.ToString();

                    //獲取工單數據
                    SqlCommand scomm3 = new SqlCommand();
                    scomm3.CommandText = "select top "+ mc +" a.*,b.* FROM [M4_DATABASE].[dbo].[FACT_ProductStatus] a left join (select [ID] as bID,[Line_ID],[Equip_ID] as eID from [M4_DATABASE].[dbo].[BASIC_INFORMATION]) b on a.BASIC_ID = bID where a.WorkOrder!= '/'  and  a.ID >= '" + IDcount + "' and a.CreateDate > '"+dtnc1+"' order by a.ID desc";
                    scomm3.Connection = sconn;
                    SqlDataReader sdreader3 = scomm3.ExecuteReader();
                    while (sdreader3.Read())
                    {
                        IDcount = sdreader3.GetInt32(0) + 1;        

                        //=-------FACT_ProductStatus
                        //消息队列路径
                        string pathps = @"FormatName:Direct=TCP:10.196.7.63\private$\orderdata";
                        MessageQueue queueps;
                        //获取这个消息队列
                        queueps = new MessageQueue(pathps);
                        string str = sdreader3["CreateDate"].ToString();
                        string ctime = "";
                        if (str != string.Empty)
                        {
                            ctime = str.Substring(0, 4) + "/" + str.Substring(4, 2) + "/" + str.Substring(6, 2) + " " + str.Substring(8, 2) + ":" + str.Substring(10, 2) + ":" + str.Substring(12, 2);
                        }
                        //Console.WriteLine(str);
                        string str11 = sdreader3["start_time"].ToString();
                        string stime = "";
                        if (str11 != string.Empty)
                        {
                            stime = str11.Substring(0, 4) + "/" + str11.Substring(4, 2) + "/" + str11.Substring(6, 2) + " " + str11.Substring(8, 2) + ":" + str11.Substring(10, 2) + ":" + str11.Substring(12, 2);
                        }
                        //Console.WriteLine(str11);
                        //Console.WriteLine(sdreader3["eID"].ToString());
                        FACT_ProductStatus PS = new FACT_ProductStatus()
                        {
                            WorkOrder = sdreader3["WorkOrder"].ToString(),
                            Equip_ID = sdreader3["eID"].ToString(),
                            Line_ID = sdreader3["Line_ID"].ToString(),
                            PN = sdreader3["PN"].ToString(),
                            //start_time = str11.Substring(0, 4) + "/" + str11.Substring(4, 2) + "/" + str11.Substring(6, 2) + " " + str11.Substring(8, 2) + ":" + str11.Substring(10, 2) + ":" + str11.Substring(12, 2),
                            start_time = stime,
                            PlanQty = sdreader3["PlanQty"].ToString(),
                            PlanInputHour = sdreader3["PlanInputHour"].ToString(),
                            //IEType = sdreader3["IEType"].ToString(),
                            Status = sdreader3["Status"].ToString(),
                            CreateDate = ctime
                        };
                        //json轉字符串
                        string mps = JsonConvert.SerializeObject(PS);
                        //Console.WriteLine(mps);
                        //定義信息
                        System.Messaging.Message msgps = new System.Messaging.Message();
                        msgps.Body = mps;
                        //msgeo.Formatter = new XmlMessageFormatter(new Type[] { typeof(string) });
                        //發送信息
                        queueps.Send(msgps);
                        //queueps.Close();
                    }
                    Console.WriteLine("OrderData" + IDcount.ToString());
                    sdreader3.Close();
                    scomm3.Dispose();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
                finally
                {
                    sconn.Dispose();
                    sconn.Close();
                    sconnsb.Clear();
                    Thread.Sleep(5000);//设定時間間隔
                }
            }
        }
        public class FACT_ProductStatus
        {
            public string WorkOrder { get; set; } //工單
            public string Equip_ID { get; set; }  //設備ID
            public string Line_ID { get; set; }   //線體ID
            public string PN { get; set; }        //料號
            public string start_time { get; set; }//工單開始時間
            public string PlanQty { get; set; }   //當前產量
            public string PlanInputHour { get; set; } //計劃產量
            //public string IEType { get; set; }
            public string Status { get; set; }   //機台狀態
            public string CreateDate { get; set; } //工單建立時間
        }
    }
}
