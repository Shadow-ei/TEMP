﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Net;
using System.Net.Sockets;
using RabbitMQ;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System.Data;
using System.Data.SqlClient;
using System.Threading;

namespace ca9
{
    class Program
    {
        static void Main(string[] args)
        {
            //init();
            
            MoldParametersJSON mpJ = new MoldParametersJSON();                    //成型參數對象
            //TieBarPressuresJSON tbpJ = new TieBarPressuresJSON();               //哥林柱壓力數據對象
            //TemperaturesJSON tttJ = new TemperaturesJSON();                     //溫度數據對象
            //MouldInternalPressuresJSON mipJ = new MouldInternalPressuresJSON(); //模內壓數據對象
            JudgeResultJSON jrJ = new JudgeResultJSON();                          //智能判讀數據對象

            ExceptionDataJSON edJ = new ExceptionDataJSON();                      //異常數據及處理數據對象

            OrderDataJson odJ = new OrderDataJson();                              //工單數據對象

            EquipStopJSON esJ = new EquipStopJSON();                              //設備狀態數據對象


            Thread thread1 = new Thread(new ThreadStart(mpJ.sendMoldParameters)); //將mpJ加入線程1
            //thread1.IsBackground = true;
            thread1.Start();                                                      //開始線程1
            //Thread thread2 = new Thread(new ThreadStart(tbpJ.sendTieBarPressures)); //將tbpJ加入線程2
            //thread2.Start();                                                    //開始線程2
            //Thread thread3 = new Thread(new ThreadStart(tttJ.sendTemperatures));  //將tttJ加入線程3
            //thread3.Start();                                                    //開始線程3
            //Thread thread4 = new Thread(new ThreadStart(mipJ.sendMouldInternalPressures));  //將mipJ加入線程4
            //thread4.Start();                                                    //開始線程4
            Thread thread5 = new Thread(new ThreadStart(jrJ.sendTJudgeResult));   //將jrJ加入線程5
            //thread5.IsBackground = true;
            thread5.Start();                                                      //開始線程5

            Thread thread6 = new Thread(new ThreadStart(edJ.sendExceptionData));  //將edJ加入線程6
            thread6.Start();                                                      //開始線程6

            Thread thread7 = new Thread(new ThreadStart(odJ.sendOrderData));      //將odJ加入線程7
            thread7.Start();                                                      //開始線程7

            Thread thread8 = new Thread(new ThreadStart(esJ.sendEquipStop));      //將esJ加入線程8
            thread8.Start();                                                      //開始線程8



            //var autoEvent = new AutoResetEvent(false);

            //var autoEvent1 = new AutoResetEvent(false);
            //var statusChecker1 = new StatusChecker1();
            //var stateTimer1 = new Timer(statusChecker1.CheckStatus, autoEvent1, 5000, 5000);

            //var autoEvent2 = new AutoResetEvent(false);
            //var statusChecker2 = new StatusChecker2();
            //var stateTimer2 = new Timer(statusChecker2.CheckStatus, autoEvent2, 1000, 400);

            //var autoEvent3 = new AutoResetEvent(false);
            //var statusChecker3 = new StatusChecker3();
            //var stateTimer3 = new Timer(statusChecker3.CheckStatus, autoEvent3, 2000, 10000);

            //var autoEvent4 = new AutoResetEvent(false);
            //var statusChecker4 = new StatusChecker4();
            //var stateTimer4 = new Timer(statusChecker4.CheckStatus, autoEvent4, 3000, 12000);

            //autoEvent.WaitOne();
            //sconn.Dispose();
            //sconn.Close();
        }
        public static void init()
        {
            //初始化數據庫主機
            Console.WriteLine("Please enter database IP:  E.g,127.0.0.1");
            DataBase.DataSource = Console.ReadLine();
            Console.WriteLine("Please enter database Name: ");
            DataBase.InitialCatalog = Console.ReadLine();
            Console.WriteLine("Please enter database userID: ");
            DataBase.UserID = Console.ReadLine();
            Console.WriteLine("Please enter database passWord: ");
            DataBase.Password = Console.ReadLine();
            //初始化rabbitMQ主機
            Console.WriteLine("Please enter rabbitMQ IP:  E.g,127.0.0.1");
          //  RabbitServer.HostName = Console.ReadLine();
            Console.WriteLine("Please enter rabbitMQ userName: ");
          //  RabbitServer.UserName = Console.ReadLine();
            Console.WriteLine("Please enter rabbitMQ passWord: ");
         //   RabbitServer.Password = Console.ReadLine();
        }
        //class StatusChecker1
        //{
        //    moldparametersJSON mpJ = new moldparametersJSON();
        //    public StatusChecker1()
        //    {
        //    }
        //    public void CheckStatus(Object stateInfo)
        //    {
        //        //AutoResetEvent autoEvent = (AutoResetEvent)stateInfo;
        //        mpJ.sendmoldparameters();
        //    }
        //}
        //class StatusChecker2
        //{
        //    tiebarpressuresJSON tbpJ = new tiebarpressuresJSON();
        //    public StatusChecker2()
        //    {
        //    }
        //    public void CheckStatus(Object stateInfo)
        //    {
        //        //AutoResetEvent autoEvent = (AutoResetEvent)stateInfo;
        //        tbpJ.sendtiebarpressures();
        //    }
        //}
        //class StatusChecker3
        //{
        //    temperaturesJSON tttJ = new temperaturesJSON();
        //    public StatusChecker3()
        //    {
        //    }
        //    public void CheckStatus(Object stateInfo)
        //    {
        //        //AutoResetEvent autoEvent = (AutoResetEvent)stateInfo;
        //        tttJ.sendtemperatures();
        //    }
        //}
        //class StatusChecker4
        //{
        //    mouldinternalpressuresJSON mipJ = new mouldinternalpressuresJSON();
        //    public StatusChecker4()
        //    {
        //    }
        //    public void CheckStatus(Object stateInfo)
        //    {
        //        //AutoResetEvent autoEvent = (AutoResetEvent)stateInfo;
        //        mipJ.sendmouldinternalpressures();
        //    }
        //}
    }

    // * 创建连接连接到MabbitMQ
    // */
    //ConnectionFactory factory = new ConnectionFactory();
    ////设置MabbitMQ所在主机ip或者主机名
    //factory.HostName = "10.167.194.195";
    //factory.Port = 5672;
    //factory.UserName = "test";
    //factory.Password = "123456";
    ////创建一个连接
    //IConnection connection = factory.CreateConnection();
    ////创建一个频道
    //IModel channel = connection.CreateModel();
    ////指定一个队列
    //channel.QueueDeclare(queue: "molding_cloud.moldparameters",
    //         durable: true,
    //         exclusive: false,
    //         autoDelete: false,
    //         arguments: null);
    ////发送的消息
    //string wmessage = "";
    //var wbody = Encoding.UTF8.GetBytes(wmessage);
    ////往队列中发出一条消息
    //channel.BasicPublish(exchange: "",
    //                     routingKey: "molding_cloud.moldparameters",
    //                     basicProperties: null,
    //                     body: wbody);

    //Console.WriteLine(" [x] Sent {0}", wmessage);

    ////Console.WriteLine(" Press [enter] to exit.");
    ////Console.ReadLine();

    //var consumer = new EventingBasicConsumer(channel);
    //consumer.Received += (model, ea) =>
    //{
    //    var rbody = ea.Body;
    //    var rmessage = Encoding.UTF8.GetString(rbody);
    //    Console.WriteLine(" [x] Received {0}", rmessage);
    //};
    //channel.BasicConsume(queue: "molding_cloud.moldparameters",
    //                     noAck: true,
    //                     consumer: consumer);

    //Console.WriteLine(" Press [enter] to exit.");
    //Console.ReadLine();



    ////关闭频道和连接
    //channel.Close();
    //connection.Close();
}
