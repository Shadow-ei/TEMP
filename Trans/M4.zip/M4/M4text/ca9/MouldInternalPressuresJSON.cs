﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using RabbitMQ;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using Newtonsoft;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json.Converters;
using System.Threading;

namespace ca9
{
    //模內壓數據    暫未用   Fii
    class MouldInternalPressuresJSON
    {
        public Int32 IDcount = 0;
        public void sendMouldInternalPressures()
        {
            while (true)
            {
                //數據庫連接
                SqlConnectionStringBuilder sconnsb = new SqlConnectionStringBuilder();
                sconnsb.DataSource = DataBase.DataSource;
                sconnsb.InitialCatalog = DataBase.InitialCatalog;
                sconnsb.UserID = DataBase.UserID;
                sconnsb.Password = DataBase.Password;
                sconnsb.MultipleActiveResultSets = true;
                SqlConnection sconn = new SqlConnection(sconnsb.ToString());
                try
                {
                    sconn.Open();

                    //獲取模內壓數據
                    SqlCommand scomm4 = new SqlCommand();
                    scomm4.CommandText = "select top 24 a.*,b.* from Mold_Internal_Pressure_Wave_Data a left join (select [MACHINE_ID],[PRODUCT_NUMBER],[MOULD_NUMBER],[MOULD_INTERNAL_PRESSURE_MODULE] from BASIC_INFORMATION) b on a.MODULE = b.MOULD_INTERNAL_PRESSURE_MODULE where a.ID >= '" + IDcount + "' order by a.ID desc ";
                    scomm4.Connection = sconn;
                    SqlDataReader sdreader4 = scomm4.ExecuteReader();
                    while (sdreader4.Read())
                    {
                        if (sdreader4["MOULD_INTERNAL_PRESSURE_MODULE"].ToString() == "")
                        {
                            ///Console.WriteLine("暫無有效數據！");
                        }
                        else
                        {
                            IDcount = sdreader4.GetInt32(0)+24;
                            MouldInternalPressures mip = new MouldInternalPressures()
                            {
                                SCADA_ID = sdreader4["MACHINE_ID"].ToString(),
                                Production_Series = "",
                                PRODUCT_NUMBER = sdreader4["PRODUCT_NUMBER"].ToString(),
                                MOULD_NUMBER = sdreader4["MOULD_NUMBER"].ToString(),
                                MODULE = sdreader4["MODULE"].ToString(),
                                ELAPSEN_TIME = sdreader4["ElapsedTime"].ToString(),
                                SHOT_COUNT = sdreader4["ShotCount"].ToString(),
                                Cav1_R = sdreader4["Cav1_R"].ToString(),
                                Cav1_L = sdreader4["Cav1_L"].ToString(),
                                Cav2_R = sdreader4["Cav2_R"].ToString(),
                                Cav2_L = sdreader4["Cav2_L"].ToString(),
                                Cav3_R = sdreader4["Cav3_R"].ToString(),
                                Cav3_L = sdreader4["Cav3_L"].ToString(),
                                Cav4_R = sdreader4["Cav4_R"].ToString(),
                                Cav4_L = sdreader4["Cav4_L"].ToString(),
                                SEND_TIME = DateTime.Now.ToString("yyyyMMddHHmmss")
                            };
                            Mould mouldjson = new Mould()
                            {
                                MACHINE_TYPE = "mould",
                                MESSAGE = mip
                            };
                            string wmessage = JsonConvert.SerializeObject(mouldjson);
                            ///**
                            // * 创建连接连接到MabbitMQ
                            // */
                            ConnectionFactory factory = new ConnectionFactory();
                            //设置MabbitMQ所在主机ip或者主机名
                            factory.HostName = RabbitServer.HostName;
                            factory.Port = RabbitServer.Port;
                            factory.UserName = RabbitServer.UserName;
                            factory.Password = RabbitServer.Password;
                           // 创建一个连接
                           IConnection connection = factory.CreateConnection();
                            //创建一个频道
                            IModel channel = connection.CreateModel();
                            //指定一个队列
                            channel.QueueDeclare(queue: "molding_cloud.mouldinternalpressures",
                                     durable: true,
                                     exclusive: false,
                                     autoDelete: false,
                                     arguments: null);
                            //发送的消息
                            var wbody = Encoding.UTF8.GetBytes(wmessage);
                            //往队列中发出一条消息
                            channel.BasicPublish(exchange: "",
                                                 routingKey: "molding_cloud.mouldinternalpressures",
                                                 basicProperties: null,
                                                 body: wbody);
                            channel.Dispose();
                            channel.Close();
                            connection.Dispose();
                        }
                    }
                    Console.WriteLine("mould" + IDcount.ToString());
                    sdreader4.Close();
                    scomm4.Dispose();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
                finally
                {
                    sconn.Dispose();
                    sconn.Close();
                    sconnsb.Clear();
                    Thread.Sleep(5000);//阻止设定时间
                }
            }
        }
        public class Mould
        {
            public string MACHINE_TYPE { get; set; }
            public MouldInternalPressures MESSAGE { get; set; }
        }
        public class MouldInternalPressures
        {
            public string SCADA_ID { get; set; }
            public string Production_Series { get; set; }
            public string PRODUCT_NUMBER { get; set; }
            public string MOULD_NUMBER { get; set; }
            public string MODULE { get; set; }
            public string ELAPSEN_TIME { get; set; }
            public string SHOT_COUNT { get; set; }
            public string Cav1_R { get; set; }
            public string Cav1_L { get; set; }
            public string Cav2_R { get; set; }
            public string Cav2_L { get; set; }
            public string Cav3_R { get; set; }
            public string Cav3_L { get; set; }
            public string Cav4_R { get; set; }
            public string Cav4_L { get; set; }
            public string SEND_TIME { get; set; }
        }
    }
}
