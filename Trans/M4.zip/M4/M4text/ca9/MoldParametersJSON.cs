﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using RabbitMQ;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using Newtonsoft;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json.Converters;
using System.Threading;
using System.Messaging;

namespace ca9
{
    class MoldParametersJSON
    {
        public bool isNewOrder = false; //新工單標誌
        public int orderCount = 0;      //新工單產量   
        
        public void sendMoldParameters()
        {
            bool isShift = true; //換班標誌
            int shiftCount = 0;  //換班時產量記錄

            while (true)
            {
                //連接數據庫
                SqlConnectionStringBuilder sconnsb = new SqlConnectionStringBuilder();
                sconnsb.DataSource = DataBase.DataSource;
                sconnsb.InitialCatalog = DataBase.InitialCatalog;
                sconnsb.UserID = DataBase.UserID;
                sconnsb.Password = DataBase.Password;
                sconnsb.MultipleActiveResultSets = true;
                SqlConnection sconn = new SqlConnection(sconnsb.ToString());

                try
                {
                    //Console.WriteLine("aaaaa");
                    sconn.Open();
                    //獲取機台 ID 列表
                    SqlCommand scomm1 = new SqlCommand();
                    scomm1.CommandText = "select [ID] from BASIC_INFORMATION ";
                    scomm1.Connection = sconn;
                    SqlDataReader sdreader1 = scomm1.ExecuteReader();
                    while (sdreader1.Read())
                    {
                        string IDstr = sdreader1["ID"].ToString();                   //----機台 ID M4

                        //獲取每個機台 當前的基本信息及成型條件
                        SqlCommand scomm9 = new SqlCommand();
                        scomm9.CommandText = "select top 1 a.*,b.* from MOLD_DATA a right join (select [ID],[MACHINE_ID],[LAST_SHOT_CATCH_TIME],[MACHINE_NUMBER],[MACHINE_MODEL],[SCREW_DIAMETER],[PRODUCT_MATERIAL],[MOLD_HOLE_NO] ,[PRODUCT_NUMBER],[MOULD_NUMBER],[CONNECT_STATUS],[OPERATING_STATUS],[LAST_SHOT_COUNT],[LAST_SCREW_BACK_POS],[ACTUAL_COUNT],[DEPARTMENT],[KE],[PRODUCT_SERIES],[PLAN_COUNT],[Line_ID],[Equip_ID] from BASIC_INFORMATION where ID = '" + IDstr+"') b on a.BASIC_ID = b.ID order by a.ID desc";
                        scomm9.Connection = sconn;
                        SqlDataReader sdreader9 = scomm9.ExecuteReader();
                        while (sdreader9.Read())
                        {
                            //Console.WriteLine("bbbbb");
                            //設備ID 線體ID  PDM專用
                            string equipID = sdreader9["Equip_ID"].ToString();
                            string lineID = sdreader9["Line_ID"].ToString();

                            //計算OEE 達成率 模具上次保養時間 模具已生產時間 設備運行狀態
                            string machineStatus = "10";
                              //string machineStatus = "8";
                            //判定機台狀態  並將判定結果寫入相應位置
                            if (sdreader9["CONNECT_STATUS"].Equals("1") && sdreader9["OPERATING_STATUS"].Equals("1"))
                            {
                                machineStatus = "1";
                               // machineStatus = "0";
                            }
                            else if (sdreader9["CONNECT_STATUS"].Equals("1") && sdreader9["OPERATING_STATUS"].Equals("2"))
                            {
                                machineStatus = "2";
                               // machineStatus = "10";
                            }
                            else if (sdreader9["CONNECT_STATUS"].Equals("1") && sdreader9["OPERATING_STATUS"].Equals("3"))
                            {
                                machineStatus = "3";
                               // machineStatus = "8";
                            }
                            else if (sdreader9["CONNECT_STATUS"].Equals("-1") || sdreader9["CONNECT_STATUS"].Equals(null))
                            {
                                machineStatus = "0";
                               // machineStatus = "30";
                                
                            }
                            else
                            {
                                machineStatus = "0";
                            }


                            double Titl1 = 0;  //總投入時間

                            DateTime dtn = DateTime.Now;    //當前時間
                            DateTime dtns = new DateTime(); //起始日期
                            DateTime dds = new DateTime();  //起始日期+時間
                            string dtn1 = ""; //起始時間
                            int dtny = dtn.Year;
                            int dtnm = dtn.Month;
                            int dtnd = dtn.Day;

                            string dtnStr = dtn.ToString("yyyyMMddHHmmss");
                            long dtnl = long.Parse(dtnStr);
                            long dtnSl = long.Parse(dtn.ToString("yyyyMMdd") + "075000");

                            if (dtnl >= dtnSl)
                            {
                                dtns = dtn;//後一天時間 EXTURDER_SCREW_SPEED
                            }
                            else
                            {
                                dtns = dtn.AddDays(-1);//前一天時間
                            }

                            dtn1 = dtns.ToString("yyyyMMdd") + "075000";
                            int dtnsy = dtns.Year;
                            int dtnsm = dtns.Month;
                            int dtnsd = dtns.Day;
                            dds = new DateTime(dtnsy, dtnsm, dtnsd, 07, 50, 00);//起始時間

                            long dtnc1 = long.Parse(dtn1);

                            string productSeries = sdreader9["PRODUCT_SERIES"].ToString();
                            int mxs = 4;
                            int pc = 0; //計劃產量
                            if (!sdreader9["MOLD_HOLE_NO"].Equals(null))
                            {
                                mxs = Convert.ToInt32(sdreader9["MOLD_HOLE_NO"]);//對應機台模穴數
                            }

                            int actualcount = 0;//即時產量
                            //if (sdreader9["ACTUAL_COUNT"] != System.DBNull.Value)
                            //    actualcount = Convert.ToInt32(sdreader9["ACTUAL_COUNT"].ToString());

                            //sun 20220922
                            //獲取該機台當前模次數
                            string sql01 = "SELECT COUNT(*) FROM [M4_DATABASE].[dbo].[MOLD_DATA] where BASIC_ID = '" + IDstr + "'  and CATCH_TIME > '" + dtnc1 + "' ";
                            SqlCommand scd01 = new SqlCommand(sql01, sconn);
                            object obj01 = scd01.ExecuteScalar();

                            int sun = int.Parse(obj01.ToString());
                            actualcount = sun * mxs;   //機台產量 PCS  
                            scd01.Dispose();

                            if (sdreader9["PLAN_COUNT"].ToString() != "")
                            {
                                pc = Convert.ToInt32(sdreader9["PLAN_COUNT"]); //計劃產量
                            }

                            //當前時間與機台初次開機起始時間的時間間隔 
                            TimeSpan ts1;                            
                            DateTime dtstarttime;
                            DateTime dtendtime= dtns;

                            string sqlMstStr = "SELECT TOP 1 [CATCH_TIME] FROM [M4_DATABASE].[dbo].[MOLD_DATA] where BASIC_ID = '" + IDstr + "' and CATCH_TIME > '" + dtnc1 + "'";
                            SqlCommand sqlMstCmd = new SqlCommand(sqlMstStr, sconn);
                            object MstObj = sqlMstCmd.ExecuteScalar();
                            if (MstObj != null)
                            {
                                int syear = Convert.ToInt32(MstObj.ToString().Substring(0, 4));
                                int sMonth = Convert.ToInt32(MstObj.ToString().Substring(4, 2));
                                int sday = Convert.ToInt32(MstObj.ToString().Substring(6, 2));
                                int sHour = Convert.ToInt32(MstObj.ToString().Substring(8, 2));
                                int smin = Convert.ToInt32(MstObj.ToString().Substring(10, 2));
                                int ssec = Convert.ToInt32(MstObj.ToString().Substring(12, 2));

                                dtstarttime = new DateTime(syear, sMonth, sday, sHour, smin, ssec);
                                ts1 = dtn - dtstarttime;
                            }
                            else
                            {
                                ts1 = dtn - dtn;
                                //dtstarttime = DateTime.Now.AddDays(1);
                            }
                            sqlMstCmd.Dispose();
                            //總投入時間時間
                            Titl1 = ts1.TotalSeconds; 

                            TimeSpan ts = new TimeSpan();
                            double sumts = 0;

                            //已停機時間
                            string sqlsssjs = "SELECT [DateTime_Before],[DateTime_Now] FROM [M4_DATABASE].[dbo].[Machine_Status_Resume] where BASIC_ID = '" + IDstr + "' and [Status_Before] != 1 and [DateTime_Before] > '" + dtnc1 + "' ";
                            SqlDataAdapter sqlsda3 = new SqlDataAdapter(sqlsssjs, sconn);
                            DataTable dtsssj = new DataTable();
                            sqlsda3.Fill(dtsssj);
                            if (dtsssj.Rows.Count != 0)
                            {
                                for (int iii = 0; iii < dtsssj.Rows.Count; iii++)
                                {
                                    string mstarttime = dtsssj.Rows[iii][0].ToString();
                                    string mendtime = dtsssj.Rows[iii][1].ToString();

                                    int syear = Convert.ToInt32(mstarttime.Substring(0, 4));
                                    int sMonth = Convert.ToInt32(mstarttime.Substring(4, 2));
                                    int sday = Convert.ToInt32(mstarttime.Substring(6, 2));
                                    int sHour = Convert.ToInt32(mstarttime.Substring(8, 2));
                                    int smin = Convert.ToInt32(mstarttime.Substring(10, 2));
                                    int ssec = Convert.ToInt32(mstarttime.Substring(12, 2));
                                    DateTime dtstarttime1 = new DateTime(syear, sMonth, sday, sHour, smin, ssec);

                                    int eyear = Convert.ToInt32(mendtime.Substring(0, 4));
                                    int eMonth = Convert.ToInt32(mendtime.Substring(4, 2));
                                    int eday = Convert.ToInt32(mendtime.Substring(6, 2));
                                    int eHour = Convert.ToInt32(mendtime.Substring(8, 2));
                                    int emin = Convert.ToInt32(mendtime.Substring(10, 2));
                                    int esec = Convert.ToInt32(mendtime.Substring(12, 2));

                                    DateTime dtendtime1 = new DateTime(eyear, eMonth, eday, eHour, emin, esec);
                                    ts = dtendtime1 - dtstarttime1;
                                    sumts += ts.TotalSeconds;
                                }
                            }
                            dtsssj.Dispose();
                            sqlsda3.Dispose();

                            //正在停機的時間
                            if (machineStatus != "1")
                            {
                                TimeSpan tsMet = new TimeSpan();
                                string sqlMetStr = "SELECT TOP 1 [DateTime_Now] FROM [M4_DATABASE].[dbo].[Machine_Status_Resume] where BASIC_ID = '" + IDstr + "' and Status_Now != 1 and DateTime_Now > '" + dtnc1 + "' order by ID desc";
                                SqlCommand sqlMetCmd = new SqlCommand(sqlMetStr, sconn);
                                object MetObj = sqlMetCmd.ExecuteScalar();
                                if (MetObj != null)
                                {
                                    int eyear = Convert.ToInt32(MetObj.ToString().Substring(0, 4));
                                    int eMonth = Convert.ToInt32(MetObj.ToString().Substring(4, 2));
                                    int eday = Convert.ToInt32(MetObj.ToString().Substring(6, 2));
                                    int eHour = Convert.ToInt32(MetObj.ToString().Substring(8, 2));
                                    int emin = Convert.ToInt32(MetObj.ToString().Substring(10, 2));
                                    int esec = Convert.ToInt32(MetObj.ToString().Substring(12, 2));

                                    dtendtime = new DateTime(eyear, eMonth, eday, eHour, emin, esec);
                                    tsMet = DateTime.Now - dtendtime;
                                }
                                else
                                {
                                    tsMet = DateTime.Now - dds;
                                    //dtendtime = DateTime.Now.AddHours(4);
                                }
                                sqlMetCmd.Dispose();
                                sumts += tsMet.TotalSeconds;
                            }

                            //減去已清模時間
                            string querrysqlm = "SELECT [MAINTENANCE_START_DATE],[MAINTENANCE_END_DATE],[MAINTENANCE_CONTENT] FROM [M4_DATABASE].[dbo].[MAINTENANCE_RECORD] where BASIC_ID = '" + IDstr + "' and [MAINTENANCE_START_DATE] > '" + dtnc1 + "' and [MAINTENANCE_CODE] = '0' and LEN(MAINTENANCE_END_DATE)=14 and LEN(MAINTENANCE_START_DATE)=14  ";
                            SqlDataAdapter sdam = new SqlDataAdapter(querrysqlm, sconn);
                            DataTable dtm = new DataTable();
                            sdam.Fill(dtm);
                            sdam.Dispose();

                            foreach (DataRow drm in dtm.Rows)
                            {
                                string mstarttime = drm["MAINTENANCE_START_DATE"].ToString();
                                string mendtime = drm["MAINTENANCE_END_DATE"].ToString();

                                int syear = Convert.ToInt32(mstarttime.Substring(0, 4));
                                int sMonth = Convert.ToInt32(mstarttime.Substring(4, 2));
                                int sday = Convert.ToInt32(mstarttime.Substring(6, 2));
                                int sHour = Convert.ToInt32(mstarttime.Substring(8, 2));
                                int smin = Convert.ToInt32(mstarttime.Substring(10, 2));
                                int ssec = Convert.ToInt32(mstarttime.Substring(12, 2));
                                DateTime dtstarttime2 = new DateTime(syear, sMonth, sday, sHour, smin, ssec);

                                int eyear = Convert.ToInt32(mendtime.Substring(0, 4));
                                int eMonth = Convert.ToInt32(mendtime.Substring(4, 2));
                                int eday = Convert.ToInt32(mendtime.Substring(6, 2));
                                int eHour = Convert.ToInt32(mendtime.Substring(8, 2));
                                int emin = Convert.ToInt32(mendtime.Substring(10, 2));
                                int esec = Convert.ToInt32(mendtime.Substring(12, 2));

                                DateTime dtendtime2 = new DateTime(eyear, eMonth, eday, eHour, emin, esec);
                                ts = dtendtime2 - dtstarttime2;
                                sumts -= ts.TotalSeconds;
                            }
                            dtm.Clear();
                            dtm.Dispose();

                            // 減去正在清模具的時間
                            string querrysqlm1 = "SELECT [MAINTENANCE_START_DATE],[MAINTENANCE_END_DATE],[MAINTENANCE_CONTENT] FROM [M4_DATABASE].[dbo].[MAINTENANCE_RECORD] where BASIC_ID = '" + IDstr + "' and [MAINTENANCE_START_DATE] > '" + dtnc1 + "' and [MAINTENANCE_CODE] = '0' and LEN(MAINTENANCE_END_DATE)='' and LEN(MAINTENANCE_START_DATE)=14  ";
                            SqlDataAdapter sdam1 = new SqlDataAdapter(querrysqlm1, sconn);
                            DataTable dtm1 = new DataTable();
                            sdam1.Fill(dtm1);
                            sdam1.Dispose();

                            foreach (DataRow drm1 in dtm1.Rows)
                            {
                                string mstarttime = drm1["MAINTENANCE_START_DATE"].ToString();

                                int syear = Convert.ToInt32(mstarttime.Substring(0, 4));
                                int sMonth = Convert.ToInt32(mstarttime.Substring(4, 2));
                                int sday = Convert.ToInt32(mstarttime.Substring(6, 2));
                                int sHour = Convert.ToInt32(mstarttime.Substring(8, 2));
                                int smin = Convert.ToInt32(mstarttime.Substring(10, 2));
                                int ssec = Convert.ToInt32(mstarttime.Substring(12, 2));
                                DateTime stime = new DateTime(syear, sMonth, sday, sHour, smin, ssec);

                                ts = DateTime.Now - stime;
                                sumts -= ts.TotalSeconds;
                            }
                            dtm1.Clear();
                            dtm1.Dispose();

                            //減去已正常停機時間
                            string querrysqlm2 = "SELECT [MAINTENANCE_START_DATE],[MAINTENANCE_END_DATE],[MAINTENANCE_CONTENT] FROM [M4_DATABASE].[dbo].[MAINTENANCE_RECORD] where BASIC_ID = '" + IDstr + "' and [MAINTENANCE_START_DATE] > '" + dtnc1 + "' and [MAINTENANCE_CODE] = '10' and LEN(MAINTENANCE_END_DATE)=14 and LEN(MAINTENANCE_START_DATE)=14  ";
                            SqlDataAdapter sdam2 = new SqlDataAdapter(querrysqlm2, sconn);
                            DataTable dtm2 = new DataTable();
                            sdam2.Fill(dtm2);
                            sdam2.Dispose();

                            foreach (DataRow drm in dtm2.Rows)
                            {
                                string mstarttime = drm["MAINTENANCE_START_DATE"].ToString();
                                string mendtime = drm["MAINTENANCE_END_DATE"].ToString();

                                int syear = Convert.ToInt32(mstarttime.Substring(0, 4));
                                int sMonth = Convert.ToInt32(mstarttime.Substring(4, 2));
                                int sday = Convert.ToInt32(mstarttime.Substring(6, 2));
                                int sHour = Convert.ToInt32(mstarttime.Substring(8, 2));
                                int smin = Convert.ToInt32(mstarttime.Substring(10, 2));
                                int ssec = Convert.ToInt32(mstarttime.Substring(12, 2));
                                DateTime dtstarttime3 = new DateTime(syear, sMonth, sday, sHour, smin, ssec);

                                int eyear = Convert.ToInt32(mendtime.Substring(0, 4));
                                int eMonth = Convert.ToInt32(mendtime.Substring(4, 2));
                                int eday = Convert.ToInt32(mendtime.Substring(6, 2));
                                int eHour = Convert.ToInt32(mendtime.Substring(8, 2));
                                int emin = Convert.ToInt32(mendtime.Substring(10, 2));
                                int esec = Convert.ToInt32(mendtime.Substring(12, 2));

                                DateTime dtendtime2 = new DateTime(eyear, eMonth, eday, eHour, emin, esec);
                                ts = dtendtime2 - dtstarttime3;
                                sumts -= ts.TotalSeconds;
                            }
                            dtm2.Clear();
                            dtm2.Dispose();

                            // 機台當天正在正常停機的記錄
                            string querrysqlm3 = "SELECT [MAINTENANCE_START_DATE],[MAINTENANCE_END_DATE],[MAINTENANCE_CONTENT] FROM [M4_DATABASE].[dbo].[MAINTENANCE_RECORD] where BASIC_ID = '" + IDstr + "' and [MAINTENANCE_START_DATE] > '" + dtnc1 + "' and [MAINTENANCE_CODE] = '10' and LEN(MAINTENANCE_END_DATE)='' and LEN(MAINTENANCE_START_DATE)=14  ";
                            SqlDataAdapter sdam3 = new SqlDataAdapter(querrysqlm3, sconn);
                            DataTable dtm3 = new DataTable();
                            sdam3.Fill(dtm3);
                            sdam3.Dispose();

                            foreach (DataRow drm3 in dtm3.Rows)
                            {
                                string mstarttime = drm3["MAINTENANCE_START_DATE"].ToString();

                                int syear = Convert.ToInt32(mstarttime.Substring(0, 4));
                                int sMonth = Convert.ToInt32(mstarttime.Substring(4, 2));
                                int sday = Convert.ToInt32(mstarttime.Substring(6, 2));
                                int sHour = Convert.ToInt32(mstarttime.Substring(8, 2));
                                int smin = Convert.ToInt32(mstarttime.Substring(10, 2));
                                int ssec = Convert.ToInt32(mstarttime.Substring(12, 2));
                                DateTime stime = new DateTime(syear, sMonth, sday, sHour, smin, ssec);

                                ts = DateTime.Now - stime;
                                sumts -= ts.TotalSeconds;
                            }
                            dtm3.Clear();
                            dtm3.Dispose();

                            //稼動時間    稼動時間 = 總投入時間- 負荷時間(0) - 損失時間 
                            double jiaDongTime = Titl1;
                            if (Titl1 > sumts)
                                jiaDongTime = Titl1 - Convert.ToInt32(sumts);
                            else
                                jiaDongTime = 0;

                            ////理論週期     通過最大產量計算理論週期，否則默認為 12s
                            //double dllzq = 12;           //一模的理論週期
                            //if (pc != 0 && mxs != 0)
                            //    dllzq = 3600 * 24 / (pc / mxs);

                            double zllzq = 12;           //默認理論週期
                            string zq00 = "select top 1 CYCLE_TIME FROM [M4_DATABASE].[dbo].[MOLD_CONDITIONS_SPECIFICATIONS] where BASIC_ID = '" + IDstr + "' and Product_Series = '" + productSeries + "' order by ID desc";
                            SqlCommand cmdzq = new SqlCommand(zq00, sconn);
                            object objzq = cmdzq.ExecuteScalar();

                            if (objzq != null)
                            {
                                string[] liLunZhouQi = objzq.ToString().Split('±');
                                zllzq = double.Parse(liLunZhouQi[0]);      //[MOLD_CONDITIONS_SPECIFICATIONS]表裡週期
                            }

                            double dcl = 0; //性能稼動率

                            if (jiaDongTime != 0)
                                dcl = 1.0 * actualcount / (jiaDongTime / zllzq * mxs); //計算達成率
                            if (dcl > 1)
                            {
                                //Random ran = new Random();
                                //dcl = ran.NextDouble() * (1.00 - 0.99) + 0.99;
                                dcl = 1;
                            }
                            //去掉機故及非自動模式下的模次數
                            string sqlzs = "SELECT COUNT(*) FROM [M4_DATABASE].[dbo].[TEST_RESULT] where BASIC_ID = '" + IDstr + "' and DATETIME > '" + dtnc1 + "' and TEST_MODE !=3 AND TEST_MODE !=4 ";
                            SqlCommand cmd4 = new SqlCommand(sqlzs, sconn);
                            object obj4 = cmd4.ExecuteScalar();
                            cmd4.Dispose();
                            //判讀良品的模次數
                            string sqllps = "SELECT COUNT(*) FROM [M4_DATABASE].[dbo].[TEST_RESULT] where BASIC_ID = '" + IDstr + "' and DATETIME > '" + dtnc1 + "' and TEST_MODE = '0' ";
                            SqlCommand cmd5 = new SqlCommand(sqllps, sconn);
                            object obj5 = cmd5.ExecuteScalar();
                            cmd5.Dispose();

                            int izs = 0; //總產量
                            int ips = 0; //良品數
                            double ctll = 1;
                            double jiaDongTimeLv = 0;
                            double oee1 = 0; //設備綜合利用效率OEE1

                            double okYield = 1; //默認良率

                            if (obj4 != null)
                            {
                                izs = Convert.ToInt32(obj4);
                                if (obj5 != null)
                                {
                                    ips = Convert.ToInt32(obj5);
                                }
                            }

                            if (izs == 0)
                            {
                                okYield = 1;
                            }
                            else
                            {
                                ctll = 1.0 * ips / izs; //判讀良率
                            }
                            okYield = double.Parse((ctll).ToString("f2"));   //智能判讀[M4_DATABASE].[dbo].[TEST_RESULT]的良品率

                            //時間稼動率
                            if (Titl1 != 0)
                                jiaDongTimeLv = 1.0 * jiaDongTime / Titl1;             // 稼動時間/總投入時間                       
                            else
                                jiaDongTimeLv = 0;
                                //OEE1 = 時間稼動率 * 性能稼動率 * 良品率
                            oee1 = 1.0 * jiaDongTimeLv * dcl * okYield; //計算設備綜合利用效率OEE1 

                            //string tttt = machineNO + "機台" + "性能稼動率" + dcl.ToString() + "設備綜合率" + oee1.ToString();
                            //Console.WriteLine(tttt);
                            
                            //模具已生產時間與模數
                            string oldtime = DateTime.Now.ToString("yyyyMMddHHmmss");
                            double productionTimeMould = 0;                     //模具已生產時間
                            string sqlmodel = "SELECT TOP 1 [MAINTENANCE_END_DATE] FROM [M4_DATABASE].[dbo].[MAINTENANCE_RECORD] where BASIC_ID = '" + IDstr + "' and LEN(MAINTENANCE_END_DATE)=14  and MAINTENANCE_CODE between 0 and 2 order by ID desc";
                            SqlDataAdapter sda1 = new SqlDataAdapter(sqlmodel, sconn);
                            DataTable dt1 = new DataTable();
                            sda1.Fill(dt1);
                            if (dt1.Rows.Count > 0)
                            {
                                oldtime = dt1.Rows[0][0].ToString();
                                //Console.WriteLine(oldtime);
                                int year = Convert.ToInt32(oldtime.Substring(0, 4));
                                int Month = Convert.ToInt32(oldtime.Substring(4, 2));
                                int day = Convert.ToInt32(oldtime.Substring(6, 2));
                                int Hour = Convert.ToInt32(oldtime.Substring(8, 2));
                                int min = Convert.ToInt32(oldtime.Substring(10, 2));
                                int sec = Convert.ToInt32(oldtime.Substring(12, 2));

                                DateTime dtold = new DateTime(year, Month, day, Hour, min, sec);
                                DateTime dtnew = DateTime.Now;
                                TimeSpan tss = new TimeSpan();
                                tss = dtnew - dtold;
                                productionTimeMould = tss.TotalDays;
                            }
                            sda1.Dispose();
                            dt1.Dispose();

                            bool hasWorkOrder = true;
                            string workOrder = "N/A";
                            string sqlWO = "SELECT TOP 1 [WorkOrder] FROM [M4_DATABASE].[dbo].[FACT_ProductStatus] where WorkOrder!= '/'  and  BASIC_ID = '" + IDstr + "' order by ID desc";
                            SqlCommand cmdWO = new SqlCommand(sqlWO, sconn);
                            object objWO = new object();
                            objWO = cmdWO.ExecuteScalar();
                            if(objWO !=null)
                                workOrder = objWO.ToString();
                            else
                            {
                                hasWorkOrder = false;
                            }
                            cmdWO.Dispose();

                            MoldParameters mp = new MoldParameters()
                            {
                                CATCH_TIME = sdreader9["CATCH_TIME"].ToString(),
                                SHOT_TOTAL = sdreader9["SHOT_TOTAL"].ToString(),
                                SHOT_COUNT = sdreader9["SHOT_COUNT"].ToString(),
                                PLASTIC_TIME = sdreader9["PLASTIC_TIME"].ToString(),
                                FILLING_TIME = sdreader9["FILLING_TIME"].ToString(),
                                CYCLE_TIME = sdreader9["CYCLE_TIME"].ToString(),
                                MINIMUM_CUSHION = sdreader9["MINIMUM_CUSHION"].ToString(),
                                INJECTION_SWITCH_POSITION1 = sdreader9["INJECTION_SWITCH_POSITION1"].ToString(),
                                INJECTION_SWITCH_POSITION2 = sdreader9["INJECTION_SWITCH_POSITION2"].ToString(),
                                INJECTION_SWITCH_POSITION3 = sdreader9["INJECTION_SWITCH_POSITION3"].ToString(),
                                INJECTION_SWITCH_POSITION4 = sdreader9["INJECTION_SWITCH_POSITION4"].ToString(),
                                VP_TRANSFER_POSITION_S = sdreader9["VP_TRANSFER_POSITION_S"].ToString(),
                                INJECTION_STEP = sdreader9["INJECTION_STEP"].ToString(),
                                INJECTION_VELOCITY1 = sdreader9["INJECTION_VELOCITY1"].ToString(),
                                INJECTION_VELOCITY2 = sdreader9["INJECTION_VELOCITY2"].ToString(),
                                INJECTION_VELOCITY3 = sdreader9["INJECTION_VELOCITY3"].ToString(),
                                INJECTION_VELOCITY4 = sdreader9["INJECTION_VELOCITY4"].ToString(),
                                INJECTION_VELOCITY5 = sdreader9["INJECTION_VELOCITY5"].ToString(),
                                INJECTION_TIME = sdreader9["INJECTION_TIME"].ToString(),
                                MAX_INJECTION_PRESSURE_S = sdreader9["MAX_INJECTION_PRESSURE_S"].ToString(),
                                PEAK_INJECTION_PRESSURE_R = sdreader9["PEAK_INJECTION_PRESSURE_R"].ToString(),
                                PEAK_HOLDING_PRESSURE_R = sdreader9["PEAK_HOLDING_PRESSURE_R"].ToString(),
                                PACK_PRESSURE1 = sdreader9["PACK_PRESSURE1"].ToString(),
                                PACK_PRESSURE2 = sdreader9["PACK_PRESSURE2"].ToString(),
                                PACK_PRESSURE3 = sdreader9["PACK_PRESSURE3"].ToString(),
                                PACK_PRESSURE4 = sdreader9["PACK_PRESSURE4"].ToString(),
                                PACK_TIME1 = sdreader9["PACK_TIME1"].ToString(),
                                PACK_TIME2 = sdreader9["PACK_TIME2"].ToString(),
                                PACK_TIME3 = sdreader9["PACK_TIME3"].ToString(),
                                PACK_TIME4 = sdreader9["PACK_TIME4"].ToString(),
                                MAX_PACK_VELOCITY = sdreader9["MAX_PACK_VELOCITY"].ToString(),
                                DWELL_TIME_BEFORE_INJECTION = sdreader9["DWELL_TIME_BEFORE_INJECTION"].ToString(),
                                BEFORE_EXTRUDER_PRESSURE = sdreader9["BEFORE_EXTRUDER_PRESSURE"].ToString(),
                                BEFORE_EXTRUDER_TIME = sdreader9["BEFORE_EXTRUDER_TIME"].ToString(),
                                SCREW_BACK_POSITION = sdreader9["SCREW_BACK_POSITION"].ToString(),
                                BACK_PRESSURE1 = sdreader9["BACK_PRESSURE1"].ToString(),
                                BACK_PRESSURE2 = sdreader9["BACK_PRESSURE2"].ToString(),
                                EXTURDER_SCREW_SPEED1 = sdreader9["EXTRUDER_SCREW_SPEED1"].ToString(),
                                EXTURDER_SCREW_SPEED2 = sdreader9["EXTRUDER_SCREW_SPEED2"].ToString(),
                                PRE_DECOMPRESS_VELOCITY = sdreader9["PRE_DECOMPRESS_VELOCITY"].ToString(),
                                PRE_DECOMPRESS_DISTANCE = sdreader9["PRE_DECOMPRESS_DISTANCE"].ToString(),
                                DECOMPRESS_VELOCITY = sdreader9["DECOMPRESS_VELOCITY"].ToString(),
                                DECOMPRESS_DISTANCE = sdreader9["DECOMPRESS_DISTANCE"].ToString(),
                                COOL_TIME = sdreader9["COOL_TIME"].ToString(),
                                FEED_THROAT_TEMPERATURE_S = sdreader9["FEED_THROAT_TEMPERATURE_S"].ToString(),
                                HEATER_T1_S = sdreader9["HEATER_T1_S"].ToString(),
                                HEATER_T2_S = sdreader9["HEATER_T2_S"].ToString(),
                                HEATER_T3_S = sdreader9["HEATER_T3_S"].ToString(),
                                NOZZLE1_TEMPERATURE = sdreader9["NOZZLE1_TEMPERATURE"].ToString()
                            };
                            MoldData md = new MoldData()
                            {
                                SCADA_ID = sdreader9["MACHINE_ID"].ToString(),                           //----機台 ID
                                PRODUCTION_TIME = sdreader9["LAST_SHOT_CATCH_TIME"].ToString(),          //----生產時間
                                Equipment_id = "",                                                       //----設備 ID
                                DEPARTMENT_NAME = sdreader9["DEPARTMENT"].ToString() + sdreader9["KE"].ToString(), //部門
                                MACHINE_NUMBER = sdreader9["MACHINE_NUMBER"].ToString(),                 //----機台編號
                                MACHINE_MODEL = sdreader9["MACHINE_MODEL"].ToString(),                   //----機台類型
                                PRODUCT_SERIES = sdreader9["PRODUCT_SERIES"].ToString(),                 //----產品系列
                                PRODUCT_MATERIAL = sdreader9["PRODUCT_MATERIAL"].ToString(),             //----产品原料
                                MOLD_HOLE_NO = sdreader9["MOLD_HOLE_NO"].ToString(),                     //----模穴数
                                PRODUCT_NUMBER = sdreader9["PRODUCT_NUMBER"].ToString(),                 //----产品料号
                                MOULD_NUMBER = sdreader9["MOULD_NUMBER"].ToString(),                       //----模具编号
                                                                                                           //CONNECT_STATUS = sdreader1["CONNECT_STATUS"].ToString(),                 //----联网状态
                                                                                                           //OPERATING_STATUS = sdreader1["OPERATING_STATUS"].ToString(),             //----生产状态
                                MACHINE_RUN_STATUS = machineStatus,                                                   //機臺狀態
                                LAST_SHOT_COUNT = sdreader9["LAST_SHOT_COUNT"].ToString(),               //----最新模次
                                LAST_SCREW_BACK_POS = sdreader9["LAST_SCREW_BACK_POS"].ToString(),       //----最新计量
                                                                                                         //ACTUAL_COUNT = sdreader1["ACTUAL_COUNT"].ToString(),                     //----当天实际产量
                                                                                                         //PLANT_COUNT = sdreader1["PLANT_COUNT"].ToString(),                       //---計劃產量
                                ACHIEVEMENT_RATE = dcl.ToString(),                                                     //達成率
                                OK_YIELD = okYield.ToString(),
                                OEE1 = oee1.ToString(),                                                                 //OEE1
                                LAST_MOULD_MAINTENANCE_TIME = oldtime,                                          //上次模具保養時間
                                MOULD_SERVICE_TIME = productionTimeMould.ToString(),                            //模具使用時間
                                moldparameter = mp,                                                      //----成型條件
                                SEND_TIME = DateTime.Now.ToString("yyyyMMddHHmmss")                      //----發送時間
                            };
                            Molding moldingjson = new Molding()
                            {
                                MACHINE_TYPE = "molding",
                                MESSAGE = md
                            };
                            string wmessage = JsonConvert.SerializeObject(moldingjson);
                           // Console.WriteLine("oee"+wmessage);
                            //Console.ReadKey();
                            /**
                             * 创建连接连接到MabbitMQ    傳送給 Fii
                             */
                            ConnectionFactory factory = new ConnectionFactory();
                            factory.HostName = RabbitServer.HostName;
                            factory.Port = RabbitServer.Port;
                            factory.UserName = RabbitServer.UserName;
                            factory.Password = RabbitServer.Password;
                            //创建一个连接
                            IConnection connection = factory.CreateConnection();
                            //创建一个频道
                            IModel channel = connection.CreateModel();
                            //指定一个队列
                            channel.QueueDeclare(queue: "molding_cloud.moldparameters",
                                     durable: true,
                                     exclusive: false,
                                     autoDelete: false,
                                     arguments: null);
                            //发送的消息
                            var wbody = Encoding.UTF8.GetBytes(wmessage);
                            //往队列中发出一条消息
                            channel.BasicPublish(exchange: "",
                                                 routingKey: "molding_cloud.moldparameters",
                                                 basicProperties: null,
                                                 body: wbody);
                            channel.Dispose();
                            channel.Close();
                            connection.Dispose();

                            //*****************messagequeue****************--------
                            //晚班開始時間 清零產量
                            string nightWork = "";
                            string dayWork = "";
                            nightWork = DateTime.Now.ToString("yyyy-MM-dd") + " 19:50:00";
                            dayWork = DateTime.Now.ToString("yyyy-MM-dd") + " 07:50:00";

                            if (isShift && DateTime.Now >= Convert.ToDateTime(nightWork))
                            {
                                shiftCount = actualcount;  //白班產量記錄
                                isShift = false;
                            }
                            else if(DateTime.Now >= Convert.ToDateTime(dayWork) && DateTime.Now < Convert.ToDateTime(nightWork)) //白班時間段
                            {
                                shiftCount = 0;
                                isShift = true;
                            }

                            if (hasWorkOrder) //判斷是否有工單信息
                            {
                                //------FACT_EquipOutput  傳送到 DPM
                                FACT_EquipOutput EO = new FACT_EquipOutput()
                                {
                                    Equip_ID = equipID,
                                    Line_ID = lineID,
                                    PN = sdreader9["PRODUCT_NUMBER"].ToString(),
                                    WorkOrder = workOrder,
                                    Qty = Math.Abs(actualcount-shiftCount).ToString(),
                                   // Qty = Math.Abs(actualcount-shiftCount).ToString(),
                                    Target_Rate = "0.98",
                                    Act_Rate = okYield.ToString("f4"),
                                    Target_CT = zllzq.ToString(),
                                    Act_CT = sdreader9["CYCLE_TIME"].ToString(),
                                    TimeRate = jiaDongTimeLv.ToString("f4"),
                                    RunTime = Titl1.ToString("f2"),
                                    LostTime = sumts.ToString("f2"),
                                    CreateDate = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
                                };

                                string meo = JsonConvert.SerializeObject(EO);
                                Console.WriteLine("MOLD"+meo);
                                //消息队列路径
                                string patheo = @"FormatName:Direct=TCP:10.196.7.63\private$\qtydata";
                                MessageQueue queueeo;
                                //若是存在指定路径的消息队列 
                                //if (MessageQueue.Exists(patheo))
                                //{
                                //    //获取这个消息队列
                                queueeo = new MessageQueue(patheo);
                                //}
                                //else
                                //{
                                //不存在，就建立一个新的，并获取这个消息队列对象
                                //queueeo = MessageQueue.Create(patheo);
                                //}
                                System.Messaging.Message msgeo = new System.Messaging.Message();
                                msgeo.Body = meo;
                                //msgeo.Formatter = new XmlMessageFormatter(new Type[] { typeof(string) });
                                queueeo.Send(msgeo);

                                //queueeo.Purge();
                                //queueeo.Close();

                                //
                            }
                        }
                        sdreader9.Close();
                        scomm9.Dispose();
                    }
                    Console.WriteLine("molding Send");
                    sdreader1.Close();
                    scomm1.Dispose();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
                finally
                {
                    sconn.Dispose();
                    sconn.Close();
                    sconnsb.Clear();
                    Thread.Sleep(5000);//设定時間間隔
                }
            }
        }
        public class Molding   //Fii
        {
            public string MACHINE_TYPE { get; set; }
            public MoldData MESSAGE { get; set; }

        }
        public class MoldData   //Fii 機台基本信息
        {
            public string SCADA_ID { get; set; }
            public string PRODUCTION_TIME { get; set; }
            public string Equipment_id { get; set; }
            public string DEPARTMENT_NAME { get; set; }
            public string MACHINE_NUMBER { get; set; }
            public string MACHINE_MODEL { get; set; }
            public string PRODUCT_SERIES { get; set; }
            public string PRODUCT_MATERIAL { get; set; }
            public string MOLD_HOLE_NO { get; set; }
            public string PRODUCT_NUMBER { get; set; }
            public string MOULD_NUMBER { get; set; }
            //public string CONNECT_STATUS { get; set; }
            //public string OPERATING_STATUS { get; set; }
            public string MACHINE_RUN_STATUS { get; set; }
            public string LAST_SHOT_COUNT { get; set; }
            public string LAST_SCREW_BACK_POS { get; set; }
            //public string ACTUAL_COUNT { get; set; }
            //public string PLANT_COUNT { get; set; }
            public string ACHIEVEMENT_RATE { get; set; }
            public string OK_YIELD { get; set; }
            public string OEE1 { get; set; }
            public string LAST_MOULD_MAINTENANCE_TIME { get; set; }
            public string MOULD_SERVICE_TIME { get; set; }

            public MoldParameters moldparameter { get; set; } 
            public string SEND_TIME { get; set; }
        }
        public class MoldParameters //Fii 成型條件
        {
            public string CATCH_TIME { get; set; }
            public string SHOT_TOTAL { get; set; }
            public string SHOT_COUNT { get; set; }
            public string PLASTIC_TIME { get; set; }
            public string FILLING_TIME { get; set; }
            public string CYCLE_TIME { get; set; }
            public string MINIMUM_CUSHION { get; set; }
            public string INJECTION_SWITCH_POSITION1 { get; set; }
            public string INJECTION_SWITCH_POSITION2 { get; set; }
            public string INJECTION_SWITCH_POSITION3 { get; set; }
            public string INJECTION_SWITCH_POSITION4 { get; set; }
            public string VP_TRANSFER_POSITION_S { get; set; }
            public string INJECTION_STEP { get; set; }
            public string INJECTION_VELOCITY1 { get; set; }
            public string INJECTION_VELOCITY2 { get; set; }
            public string INJECTION_VELOCITY3 { get; set; }
            public string INJECTION_VELOCITY4 { get; set; }
            public string INJECTION_VELOCITY5 { get; set; }
            public string INJECTION_TIME { get; set; }
            public string MAX_INJECTION_PRESSURE_S { get; set; }
            public string PEAK_INJECTION_PRESSURE_R { get; set; }
            public string PEAK_HOLDING_PRESSURE_R { get; set; }
            public string PACK_PRESSURE1 { get; set; }
            public string PACK_PRESSURE2 { get; set; }
            public string PACK_PRESSURE3 { get; set; }
            public string PACK_PRESSURE4 { get; set; }
            public string PACK_TIME1 { get; set; }
            public string PACK_TIME2 { get; set; }
            public string PACK_TIME3 { get; set; }
            public string PACK_TIME4 { get; set; }
            public string MAX_PACK_VELOCITY { get; set; }
            public string DWELL_TIME_BEFORE_INJECTION { get; set; }
            public string BEFORE_EXTRUDER_PRESSURE { get; set; }
            public string BEFORE_EXTRUDER_TIME { get; set; }
            public string SCREW_BACK_POSITION { get; set; }
            public string BACK_PRESSURE1 { get; set; }
            public string BACK_PRESSURE2 { get; set; }
            public string EXTURDER_SCREW_SPEED1 { get; set; }
            public string EXTURDER_SCREW_SPEED2 { get; set; }
            public string PRE_DECOMPRESS_VELOCITY { get; set; }
            public string PRE_DECOMPRESS_DISTANCE { get; set; }
            public string DECOMPRESS_VELOCITY { get; set; }
            public string DECOMPRESS_DISTANCE { get; set; }
            public string COOL_TIME { get; set; }
            public string FEED_THROAT_TEMPERATURE_S { get; set; }
            public string HEATER_T1_S { get; set; }
            public string HEATER_T2_S { get; set; }
            public string HEATER_T3_S { get; set; }
            public string NOZZLE1_TEMPERATURE { get; set; }
        }

        public class FACT_EquipOutput  // DPM
        {
            public string Equip_ID { get; set; }    //設備ID
            public string Line_ID { get; set; }     //線體ID
            public string PN { get; set; }          //料號
            public string WorkOrder { get; set; }   //工單
            public string Qty { get; set; }         //產量
            public string Target_Rate { get; set; } //目標良率
            public string Act_Rate { get; set; }    //實際良率
            public string Target_CT { get; set; }   //目標週期
            public string Act_CT { get; set; }      //實際週期
            public string TimeRate { get; set; }    //時間稼動率
            public string RunTime { get; set; }     //運行時間
            public string LostTime { get; set; }    //損失時間
            public string CreateDate { get; set; }  //發送時間
        }
    }
}
