﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using RabbitMQ;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using Newtonsoft;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json.Converters;
using System.Threading;
using System.Messaging;

namespace ca9
{

    //============= DPM 異常數據推送
    class ExceptionDataJSON
    {
        public Int32 IDcount = 0; //累計不重複發送數據標誌
        public Int32 IDcount1 = 0; //累計不重複發送數據標誌
        public void sendExceptionData()
        {
            while (true)
            {

                SqlConnectionStringBuilder sconnsb = new SqlConnectionStringBuilder();
                sconnsb.DataSource = DataBase.DataSource;
                sconnsb.InitialCatalog = DataBase.InitialCatalog;
                sconnsb.UserID = DataBase.UserID;
                sconnsb.Password = DataBase.Password;
                sconnsb.MultipleActiveResultSets = true;
                SqlConnection sconn = new SqlConnection(sconnsb.ToString());
                try
                {
                    //定義起始時間，每天早上7:50
                    DateTime dtn = DateTime.Now;    //當前時間
                    DateTime dtns = new DateTime(); //起始日期
                    string dtn1 = ""; //起始時間
                    int dtny = dtn.Year;
                    int dtnm = dtn.Month;
                    int dtnd = dtn.Day;

                    string dtnStr = dtn.ToString("yyyyMMddHHmmss");
                    long dtnl = long.Parse(dtnStr);
                    long dtnSl = long.Parse(dtn.ToString("yyyyMMdd") + "075000");

                    if (dtnl >= dtnSl)
                    {
                        dtns = dtn;//後一天時間
                    }
                    else
                    {
                        dtns = dtn.AddDays(-1);//前一天時間 早上7:50之前
                    }

                    dtn1 = dtns.ToString("yyyyMMdd") + "075000";
                    long dtnc1 = long.Parse(dtn1);

                    sconn.Open();

                    //獲取機台數量
                    string sql = "SELECT COUNT(ID) FROM [M4_DATABASE].[dbo].[BASIC_INFORMATION]";
                    SqlCommand cmd = new SqlCommand(sql, sconn);
                    object obj = cmd.ExecuteScalar();
                    cmd.Dispose();

                    string mc = obj.ToString();
                    //新增異常信息
                    SqlCommand scomm3 = new SqlCommand();
                    //獲取各個機台最新一筆異常數據
                    scomm3.CommandText = "select top "+ mc +" a.*,b.* From [M4_DATABASE].[dbo].[Exception_Management] a left join (select [ID] as bID,[Line_ID],[Equip_ID],[PRODUCT_NUMBER],[MOULD_NUMBER] from [M4_DATABASE].[dbo].[BASIC_INFORMATION]) b on a.BASIC_ID = bID where a.ID >= '" + IDcount + "' and a.Time_Occurrence > '" + dtnc1 + "' order by a.ID desc";
                    scomm3.Connection = sconn;
                    SqlDataReader sdreader3 = scomm3.ExecuteReader();
                    while (sdreader3.Read())
                    {
                        IDcount = sdreader3.GetInt32(0) + 1;
                        //=-------FACT_ExceptionNotice
                        //消息队列路径
                        string pathen = @"FormatName:Direct=TCP:10.196.7.63\private$\exceptiondata";
                        MessageQueue queueen;
                        //获取这个消息队列
                        queueen = new MessageQueue(pathen);
                        string str = sdreader3["Time_Occurrence"].ToString();
                        string cTime = "";
                        if (str != string.Empty)
                        {
                            //格式化時間字符串
                            cTime = str.Substring(0, 4) + "/" + str.Substring(4, 2) + "/" + str.Substring(6, 2) + " " + str.Substring(8, 2) + ":" + str.Substring(10, 2) + ":" + str.Substring(12, 2);
                        }
                        string lineID = sdreader3["Line_ID"].ToString();
                        //異常數據 Json文件
                        FACT_ExceptionNotice EN = new FACT_ExceptionNotice()
                        {
                            WorkOrder = sdreader3["WorkOrder"].ToString(),  
                            Equip_ID = sdreader3["Equip_ID"].ToString(),
                            Line_ID = sdreader3["Line_ID"].ToString(),
                            PN = sdreader3["PRODUCT_NUMBER"].ToString(),
                            ModelNO = sdreader3["MOULD_NUMBER"].ToString(),
                            ExceptionType = sdreader3["Data_Source"].ToString(),
                            ExceptionCode = sdreader3["ExceptionCode"].ToString(),
                            ExceptionDesc = sdreader3["ExceptionDesc"].ToString(),
                            CreateDate = cTime
                        };
                        //Json轉 字符串
                        string men = JsonConvert.SerializeObject(EN);

                        //if(lineID=="219")
                            //Console.WriteLine(men);

                        //實例化 Message對象
                        System.Messaging.Message msgen = new System.Messaging.Message();
                        //將信息寫入Message
                        msgen.Body = men;

                        //msgeo.Formatter = new XmlMessageFormatter(new Type[] { typeof(string) });
                        //傳送消息
                        queueen.Send(msgen);
                        //queueen.Close();
                    }
                    Console.WriteLine("ExceptionData" + IDcount.ToString());
                    sdreader3.Close();
                    scomm3.Dispose();

                    //處理異常追蹤信息(處理異常後發送)
                    SqlCommand scomm6 = new SqlCommand();
                    //獲取異常處理後數據
                    scomm6.CommandText = "select top " + mc + " a.*,b.* From [M4_DATABASE].[dbo].[Exception_Management] a left join (select [ID] as bID,[Line_ID],[Equip_ID],[PRODUCT_NUMBER],[MOULD_NUMBER] from [M4_DATABASE].[dbo].[BASIC_INFORMATION]) b on a.BASIC_ID = bID where a.ID >= '" + IDcount1 + "' and a.Finish_Date is not NULL and a.Time_Occurrence > '" + dtnc1 + "' order by a.ID desc";
                    scomm6.Connection = sconn;
                    SqlDataReader sdreader6 = scomm6.ExecuteReader();
                    while (sdreader6.Read())
                    {
                        IDcount1 = sdreader6.GetInt32(0) + 1;
                        //=-------FACT_FACT_ExceptionTrace
                        //消息队列路径
                        string pathet = @"FormatName:Direct=TCP:10.196.7.63\private$\exceptiontracedata";
                        MessageQueue queueet;
                        //获取这个消息队列
                        queueet = new MessageQueue(pathet);
                        string dstr = sdreader6["deal_Date"].ToString();
                        string fstr = sdreader6["Finish_Date"].ToString();

                        //Console.WriteLine(dstr);
                        //時間字符格式化
                        string dTime = "";
                        if (dstr.Length >= 14)
                        {
                            dTime = dstr.Substring(0, 4) + "/" + dstr.Substring(4, 2) + "/" + dstr.Substring(6, 2) + " " + dstr.Substring(8, 2) + ":" + dstr.Substring(10, 2) + ":" + dstr.Substring(12, 2);
                        }
                        string fTime = "";//異常處理 完成時間
                        if (fstr != "")
                        {
                            fTime = fstr.Substring(0, 4) + "/" + fstr.Substring(4, 2) + "/" + fstr.Substring(6, 2) + " " + fstr.Substring(8, 2) + ":" + fstr.Substring(10, 2) + ":" + fstr.Substring(12, 2);
                        }


                        string eStr = sdreader6["Time_Occurrence"].ToString();
                        string eTime = ""; //異常開始時間
                        if(eStr != "")
                        {
                            eTime = eStr.Substring(0, 4) + "/" + eStr.Substring(4, 2) + "/" + eStr.Substring(6, 2) + " " + eStr.Substring(8, 2) + ":" + eStr.Substring(10, 2) + ":" + eStr.Substring(12, 2);
                        }

                        TimeSpan tsbk = new TimeSpan();
                        tsbk = (Convert.ToDateTime(fTime) - Convert.ToDateTime(eTime)); //異常持續時間
                        string bdown = tsbk.TotalSeconds.ToString();

                        FACT_ExceptionTrace ET = new FACT_ExceptionTrace()
                        {
                            Equip_ID = sdreader6["Equip_ID"].ToString(),
                            Line_ID = sdreader6["Line_ID"].ToString(),
                            ExceptionDateTime = eTime,
                            Item1 = sdreader6["Item1"].ToString(),
                            Item2 = sdreader6["Item2"].ToString(),
                            Item3 = sdreader6["Item3"].ToString(),
                            Item4 = sdreader6["Item4"].ToString(),
                            event_CA = sdreader6["Countermeasures"].ToString(),
                            event_Charger = sdreader6["Person_Charge"].ToString(),
                            breakdown = bdown,
                            deal_Date = dTime,
                            CreateDate = fTime
                        };
                        //將Json信息轉為字符串
                        string met = JsonConvert.SerializeObject(ET);

                        string lineID = sdreader6["Line_ID"].ToString();
                        //if (lineID == "219")
                        //    Console.WriteLine(met);
                        //獲取信息
                        System.Messaging.Message msget = new System.Messaging.Message();
                        msget.Body = met;

                        //msgeo.Formatter = new XmlMessageFormatter(new Type[] { typeof(string) });
                        //發送消息
                        queueet.Send(msget);
                        //queueet.Close();

                    }
                    Console.WriteLine("ExceptionTraceData" + IDcount.ToString());
                    sdreader6.Close();
                    scomm6.Dispose();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
                finally
                {
                    sconn.Dispose();
                    sconn.Close();
                    sconnsb.Clear();
                    Thread.Sleep(5000);//设定時間間隔
                }
            }
        }
        public class FACT_ExceptionNotice
        {
            public string WorkOrder { get; set; }         //工單號
            public string Equip_ID { get; set; }          //設備ID
            public string Line_ID { get; set; }           //線體ID
            public string ModelNO { get; set; }           //模具號
            public string PN { get; set; }                //料號
            public string ExceptionType { get; set; }     //異常類型
            public string ExceptionCode { get; set; }     //異常代碼
            public string ExceptionDesc { get; set; }     //異常描述
            public string CreateDate { get; set; }        //異常建立時間
        }
        public class FACT_ExceptionTrace
        {
            public string Equip_ID { get; set; }            //設備ID
            public string Line_ID { get; set; }             //線體ID
            public string ExceptionDateTime { get; set; }   //異常發生時間
            public string Item1 { get; set; }               //異常一級科目
            public string Item2 { get; set; }               //異常二級科目               
            public string Item3 { get; set; }               //異常三級科目
            public string Item4 { get; set; }               //異常四級科目
            public string event_CA { get; set; }            //處理方法
            public string event_Charger { get; set; }       //負責人
            public string breakdown { get; set; }           //宕機時間
            public string deal_Date { get; set; }           //處理時間
            public string CreateDate { get; set; }          //完成時間
        }
    }
}
