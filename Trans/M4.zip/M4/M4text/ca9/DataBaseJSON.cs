﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace ca9
{
    class DataBase
    {
        //设置數據庫所在主机ip或者主机名
        public static string DataSource = "10.196.9.235";
        public static string InitialCatalog = "M4_DATABASE";
        public static string UserID = "sa";
        public static string Password = "fea@123456";
        public static bool MultipleActiveResultSets = true;        
    }
    class RabbitServer
    {
        //设置MabbitMQ所在主机ip或者主机名
        //"10.167.194.195"  5672;  "test";  "123456";
        //10.167.213.129     5672     tom    123456
        //http://rabbitmq-01.10-196-5-143.sslip.io
       // public static string HostName = "10.196.5.142";//"10.196.5.142";
        //public static int Port = 5672;
        //public static string UserName = "molding";//"molding";
        //public static string Password = "123456";

        public static string HostName = "10.196.5.142";//"10.196.5.142";
        public static int Port = 5672;
        public static string UserName = "molding";//"molding";
        public static string Password = "123456";
    }
}
