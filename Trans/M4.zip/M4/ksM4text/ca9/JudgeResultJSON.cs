﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using RabbitMQ;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using Newtonsoft;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json.Converters;
using System.Threading;
using System.Messaging;

namespace ca9
{

    //========================傳送 判讀數據
    class JudgeResultJSON
    {
        public Int32 IDcount = 0; //累計不重複發送數據標誌
        public void sendTJudgeResult()
        {
            while (true)
            {
                //連接數據庫
                SqlConnectionStringBuilder sconnsb = new SqlConnectionStringBuilder();
                sconnsb.DataSource = DataBase.DataSource;
                sconnsb.InitialCatalog = DataBase.InitialCatalog;
                sconnsb.UserID = DataBase.UserID;
                sconnsb.Password = DataBase.Password;
                sconnsb.MultipleActiveResultSets = true;
                SqlConnection sconn = new SqlConnection(sconnsb.ToString());
                try
                {
                    sconn.Open();

                    string sql = "SELECT COUNT(ID) FROM [M4_DATABASE].[dbo].[BASIC_INFORMATION]";
                    SqlCommand cmd = new SqlCommand(sql, sconn);
                    object obj = cmd.ExecuteScalar();
                    cmd.Dispose();
                    //機台數量
                    string mc = obj.ToString();
                    //獲取判讀結果
                    SqlCommand scomm5 = new SqlCommand();
                    scomm5.CommandText = "select top "+ mc +" a.*,b.* from TEST_RESULT a left join (select [ID],[MACHINE_ID],[MACHINE_NUMBER],[PRODUCT_NUMBER],[Line_ID],[Equip_ID] from BASIC_INFORMATION) b on a.BASIC_ID = b.ID where a.ID >= '" + IDcount + "' order by a.ID desc  ";
                    //scomm5.CommandText = "select top 24 a.*,b.* from [M4_DATABASE].[dbo].[TEST_RESULT] a left join (select [ID] as bID,[MACHINE_ID],[MACHINE_NUMBER],[PRODUCT_NUMBER] from [M4_DATABASE].[dbo].[BASIC_INFORMATION]) b on a.BASIC_ID = bID where a.ID >= '" + IDcount + "' order by a.ID desc";
                    scomm5.Connection = sconn;
                    SqlDataReader sdreader5 = scomm5.ExecuteReader();
                    while (sdreader5.Read())
                    {
                        string IDstr = sdreader5["BASIC_ID"].ToString();

                        string equipID = sdreader5["Equip_ID"].ToString();

                             if ( equipID.Length>4){
                            equipID = equipID.Substring(3);
                                
                                    }
                        string lineID = sdreader5["Line_ID"].ToString();
                            if ( lineID.Length>4){
                            lineID = lineID.Substring(3);
                                
                                    }


                        IDcount = sdreader5.GetInt32(0) + 1;
 //************************************************************************   Fii
                     //   JudgeResultData jrd = new JudgeResultData()
                     //   {
                            //DATETIME    TEST_MOLDING_COUNT  TEST_MODE    OK_YIELD    NG1_YIELD   NG2_YIELD  MACHINE_ID
                         //   MACHINE_ID = sdreader5["MACHINE_ID"].ToString(),
                          //  DATE_TIME = sdreader5["DATETIME"].ToString(),
                          //  TEST_MOLDING_COUNT = sdreader5["TEST_MOLDING_COUNT"].ToString(),
                          //  TEST_MODE = sdreader5["TEST_MODE"].ToString(),
                          //  OK_YIELD = sdreader5["OK_YIELD"].ToString(),
                            //NG1_YIELD = sdreader5["NG1_YIELD"].ToString(),
                            //NG2_YIELD = sdreader5["NG2_YIELD"].ToString(),
                         //   SEND_TIME = DateTime.Now.ToString("yyyyMMddHHmmss")
                      //  };
                     //   JudgeResultCollector judgeresultcollectorjson = new JudgeResultCollector()
                      //  {
                       //     MACHINE_TYPE = "judgeresultcollector",
                       //     MESSAGE = jrd
                       // };
                        //string wmessage = JsonConvert.SerializeObject(judgeresultcollectorjson);
                        ///**
                        // * 创建连接连接到RabbitMQ
                        // */
                       // ConnectionFactory factory = new ConnectionFactory();
                        //设置MabbitMQ所在主机ip或者主机名
                       // factory.HostName = RabbitServer.HostName;
                       // factory.Port = RabbitServer.Port;
                       // factory.UserName = RabbitServer.UserName;
                      //  factory.Password = RabbitServer.Password;
                        //创建一个连接
                      //  IConnection connection = factory.CreateConnection();
                        //创建一个频道
                       // IModel channel = connection.CreateModel();
                        //指定一个队列
                       // channel.QueueDeclare(queue: "molding_cloud.judgeresult",
                                // durable: true,
                                // exclusive: false,
                                 //autoDelete: false,
                                // arguments: null);
                        //发送的消息scomm5
                      //  var wbody = Encoding.UTF8.GetBytes(wmessage);
                        //往队列中发出一条消息
                       // channel.BasicPublish(exchange: "",
                                           //  routingKey: "molding_cloud.judgeresult",
                                            // basicProperties: null,
                                            // body: wbody);
                      //  channel.Dispose();
                      //  channel.Close();
                       // connection.Dispose();

    //***********************************************************************************    分割線

                        //=============================================== PDM  ==========起始

                        //確定起始時間，每天早上7:50
                        DateTime dtn = DateTime.Now;    //當前時間
                        DateTime dtns = new DateTime(); //起始日期
                        string dtn1 = ""; //起始時間
                        int dtny = dtn.Year;
                        int dtnm = dtn.Month;
                        int dtnd = dtn.Day;

                        string dtnStr = dtn.ToString("yyyyMMddHHmmss");
                        long dtnl = long.Parse(dtnStr);
                        long dtnSl = long.Parse(dtn.ToString("yyyyMMdd") + "075000");

                        if (dtnl >= dtnSl)
                        {
                            dtns = dtn;//後一天時間
                        }
                        else
                        {
                            dtns = dtn.AddDays(-1);//前一天時間
                        }

                        dtn1 = dtns.ToString("yyyyMMdd") + "075000";                   
                        long dtnc1 = long.Parse(dtn1);
                        //不飽模數量
                        string sqlNG1 = "SELECT COUNT(*) FROM [M4_DATABASE].[dbo].[TEST_RESULT] where BASIC_ID = '" + IDstr + "' and DATETIME > '" + dtnc1 + "' and TEST_MODE = '1' ";
                        SqlCommand cmdNG1 = new SqlCommand(sqlNG1, sconn);
                        object objNG1 = cmdNG1.ExecuteScalar();
                        cmdNG1.Dispose();
                        //毛頭數量
                        string sqlNG2 = "SELECT COUNT(*) FROM [M4_DATABASE].[dbo].[TEST_RESULT] where BASIC_ID = '" + IDstr + "' and DATETIME > '" + dtnc1 + "' and TEST_MODE = '2' ";
                        SqlCommand cmdNG2 = new SqlCommand(sqlNG2, sconn);
                        object objNG2 = cmdNG2.ExecuteScalar();
                        cmdNG2.Dispose();
                        //機故數量
                        string sqlNG3 = "SELECT COUNT(*) FROM [M4_DATABASE].[dbo].[TEST_RESULT] where BASIC_ID = '" + IDstr + "' and DATETIME > '" + dtnc1 + "' and TEST_MODE = '3' ";
                        SqlCommand cmdNG3 = new SqlCommand(sqlNG3, sconn);
                        object objNG3 = cmdNG3.ExecuteScalar();
                        cmdNG3.Dispose();
                        //異常數量
                        string sqlNG5 = "SELECT COUNT(*) FROM [M4_DATABASE].[dbo].[TEST_RESULT] where BASIC_ID = '" + IDstr + "' and DATETIME > '" + dtnc1 + "' and TEST_MODE = '5' ";
                        SqlCommand cmdNG5 = new SqlCommand(sqlNG5, sconn);
                        object objNG5 = cmdNG5.ExecuteScalar();
                        cmdNG5.Dispose();

                        //=-------FACT_DefectDetail
                        //消息队列路径
                        string pathdd = @"FormatName:Direct=TCP:10.97.3.88\private$\badqtydata";
                        MessageQueue queuedd;
                        //获取这个消息队列
                        queuedd = new MessageQueue(pathdd);

                        //發送不飽模數據
                        FACT_DefectDetail DD1 = new FACT_DefectDetail()
                        {
                            Equip_ID = equipID,
                            Line_ID = lineID,
                            PN = sdreader5["PRODUCT_NUMBER"].ToString(),
                            NG_CODE = "1",
                            NGDESC = "不飽模",
                            NG_Num = objNG1.ToString(),
                            CreateDate = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
                        };
                        string mdd1 = JsonConvert.SerializeObject(DD1);
                        //Console.WriteLine(mdd1);
                        System.Messaging.Message msgdd1 = new System.Messaging.Message();
                        msgdd1.Body = mdd1;
                        //msgeo.Formatter = new XmlMessageFormatter(new Type[] { typeof(string) });
                        //Console.WriteLine(msgdd1);
                        queuedd.Send(msgdd1);

                        //發送毛頭數據
                        FACT_DefectDetail DD2 = new FACT_DefectDetail()
                        {
                            Equip_ID = equipID,
                            Line_ID = lineID,
                            PN = sdreader5["PRODUCT_NUMBER"].ToString(),
                            NG_CODE = "2",
                            NGDESC = "毛頭",
                            NG_Num = objNG2.ToString(),
                            CreateDate = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
                        };
                        string mdd2 = JsonConvert.SerializeObject(DD2);
                        //Console.WriteLine(mdd2);
                        System.Messaging.Message msgdd2 = new System.Messaging.Message();
                        msgdd2.Body = mdd2;
                        //msgeo.Formatter = new XmlMessageFormatter(new Type[] { typeof(string) });
                        //Console.WriteLine(msgdd2);
                        queuedd.Send(msgdd2);

                        //發送機故數據
                        FACT_DefectDetail DD3 = new FACT_DefectDetail()
                        {
                            Equip_ID = equipID,
                            Line_ID = lineID,
                            PN = sdreader5["PRODUCT_NUMBER"].ToString(),
                            NG_CODE = "3",
                            NGDESC = "機故",
                            NG_Num = objNG3.ToString(),
                            CreateDate = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
                        };
                        string mdd3 = JsonConvert.SerializeObject(DD3);
                        //Console.WriteLine(mdd3);
                        System.Messaging.Message msgdd3 = new System.Messaging.Message();
                        msgdd3.Body = mdd3;
                        //msgeo.Formatter = new XmlMessageFormatter(new Type[] { typeof(string) });
                        //Console.WriteLine(msgdd3);
                        queuedd.Send(msgdd3);

                        //發送參數異常數據
                        FACT_DefectDetail DD5 = new FACT_DefectDetail()
                        {
                            Equip_ID = equipID,
                            Line_ID = lineID,
                            PN = sdreader5["PRODUCT_NUMBER"].ToString(),
                            NG_CODE = "5",
                            NGDESC = "參數異常",
                            NG_Num = objNG5.ToString(),
                            CreateDate = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
                        };
                        string mdd5 = JsonConvert.SerializeObject(DD5);
                        //Console.WriteLine(mdd5);
                        System.Messaging.Message msgdd5 = new System.Messaging.Message();
                        msgdd5.Body = mdd5;
                        //msgeo.Formatter = new XmlMessageFormatter(new Type[] { typeof(string) });
                        //Console.WriteLine(msgdd5);
                        queuedd.Send(msgdd5);

                        //queuedd.Close();
                        //
                    }
                    Console.WriteLine("judgeresultcollector" + IDcount.ToString());

                    sdreader5.Close();
                    scomm5.Dispose();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
                finally
                {
                    sconn.Dispose();
                    sconn.Close();
                    sconnsb.Clear();
                    Thread.Sleep(100000);//设定時間間隔
                }
            }
        }
        public class JudgeResultCollector     //傳輸 Fii
        {
            public string MACHINE_TYPE { get; set; }
            public JudgeResultData MESSAGE { get; set; }
        }
        public class JudgeResultData     //傳輸 Fii
        {
            //DATETIME    TEST_MOLDING_COUNT  TEST_MODE    OK_YIELD    NG1_YIELD   NG2_YIELD  MACHINE_ID
            public string MACHINE_ID { get; set; }           //機台號
            public string DATE_TIME { get; set; }            //時間
            public string TEST_MOLDING_COUNT { get; set; }   //模次
            public string TEST_MODE { get; set; }            //判讀結果
            public string OK_YIELD { get; set; }             //良品概率
            //public string NG1_YIELD { get; set; }
            //public string NG2_YIELD { get; set; }
            public string SEND_TIME { get; set; }            //發送時間
        }

        public class FACT_DefectDetail  //傳輸 DPM
        {
            public string Equip_ID { get; set; }     //設備ID
            public string Line_ID { get; set; }      //線體ID
            public string PN { get; set; }           //料號
            public string NG_CODE { get; set; }      //不良 編碼
            public string NGDESC { get; set; }       //不良描述
            public string NG_Num { get; set; }       //不良數
            public string CreateDate { get; set; }   //發送時間
        }
    }
}
