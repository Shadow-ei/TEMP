﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using RabbitMQ;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using Newtonsoft;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json.Converters;
using System.Threading;
using System.Messaging;

namespace ca9
{
    class EquipStopJSON
    {
        List<string> lastMachineStatuslist = new List<string>(); //上一模機台狀態 List
        List<DateTime> sTimeList = new List<DateTime>();         //機台狀態開始時間 List
        public void sendEquipStop()
        {
            bool isend = false;//機台狀態改變標誌
            SqlConnectionStringBuilder sconnsb0 = new SqlConnectionStringBuilder();
            sconnsb0.DataSource = DataBase.DataSource;
            sconnsb0.InitialCatalog = DataBase.InitialCatalog;
            sconnsb0.UserID = DataBase.UserID;
            sconnsb0.Password = DataBase.Password;
            sconnsb0.MultipleActiveResultSets = true;
            SqlConnection sconn0 = new SqlConnection(sconnsb0.ToString());
            sconn0.Open();
            //獲取機台數量
            string sql = "SELECT COUNT(ID) FROM [M4_DATABASE].[dbo].[BASIC_INFORMATION]";
            SqlCommand cmd = new SqlCommand(sql, sconn0);
            object obj = cmd.ExecuteScalar();
            cmd.Dispose();
            int mc = Convert.ToInt32(obj);
            //初始化 lastMachineStatuslist，sTimeList
            for (int i=0;i< mc; i++)
            {
                lastMachineStatuslist.Add("-1");
                sTimeList.Add(DateTime.Now);
            }

            cmd.Dispose();
            sconn0.Close();
            
            
            while (true)
            {
                //連接數據庫
                SqlConnectionStringBuilder sconnsb = new SqlConnectionStringBuilder();
                sconnsb.DataSource = DataBase.DataSource;
                sconnsb.InitialCatalog = DataBase.InitialCatalog;
                sconnsb.UserID = DataBase.UserID;
                sconnsb.Password = DataBase.Password;
                sconnsb.MultipleActiveResultSets = true;
                SqlConnection sconn = new SqlConnection(sconnsb.ToString());
                sconn.Open();
                //獲取機台連接狀態及ID信息
                SqlCommand scomm9 = new SqlCommand();
                scomm9.CommandText = "select [ID],[CONNECT_STATUS],[OPERATING_STATUS],[Line_ID],[Equip_ID] from BASIC_INFORMATION order by ID desc";
                scomm9.Connection = sconn;
                SqlDataReader sdreader9 = scomm9.ExecuteReader();
                int i = 0;
                while (sdreader9.Read())
                {
                    //Console.WriteLine("bbbbb");
                    string equipID = sdreader9["Equip_ID"].ToString();
                            if ( equipID.Length>4){
                            equipID = equipID.Substring(3);
                                
                                    }
                         

                            string lineID = sdreader9["Line_ID"].ToString();
                                if (  lineID.Length>4){
                             lineID = lineID.Substring(3);
                                
                                    }

                    //計算OEE 達成率 模具上次保養時間 模具已生產時間 設備運行狀態
                    string machineStatusk = "10";

                    //判定機台狀態  並將判定結果寫入相應位置
                    if (sdreader9["CONNECT_STATUS"].Equals("1") && sdreader9["OPERATING_STATUS"].Equals("1"))
                    {
                        machineStatusk = "0";  //正常1
                    }
                    else if (sdreader9["CONNECT_STATUS"].Equals("1") && sdreader9["OPERATING_STATUS"].Equals("2"))
                    {
                       // machineStatusk = "3";  //停機2
                          machineStatusk = "10"; //待命
                    }
                    else if (sdreader9["CONNECT_STATUS"].Equals("1") && sdreader9["OPERATING_STATUS"].Equals("3"))
                    {
                        machineStatusk = "8";  //試模3
                    }
                    else if (sdreader9["CONNECT_STATUS"].Equals("-1") || sdreader9["CONNECT_STATUS"].Equals(null))
                    {
                        //machineStatusk = "90030";  //斷開0
                        machineStatusk = "30";
                    }
                    else
                    {
                        machineStatusk = "30";  //斷開0
                    }

                    //狀態改變記錄
                    if (lastMachineStatuslist[i] == "-1")
                    {
                        isend = false; //程序剛啟動
                        sTimeList[i] = DateTime.Now;
                    }
                    else if(lastMachineStatuslist[i] != machineStatusk)
                    {
                        isend = true;   //機台狀態變化                  
                    }
                    else if(lastMachineStatuslist[i] == machineStatusk)
                    {
                        isend = false; //機台狀態未改變
                    }
                    else
                    {
                        isend = false;
                    }


                    //-------FACT_EquipStop
                    //消息队列路径
                    string pathes = @"FormatName:Direct=TCP:10.97.3.88\private$\statedata";
                    if (isend) //如果機台狀態改變發送end_Flag = true
                    {
                        FACT_EquipStop ES0 = new FACT_EquipStop()
                        {
                            Equip_ID = equipID,
                            Line_ID = lineID,
                            Status = lastMachineStatuslist[i],
                            start_time = sTimeList[i].ToString("yyyy/MM/dd HH:mm:ss"),
                            end_time = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"),
                            Time_length = (DateTime.Now - sTimeList[i]).TotalSeconds.ToString(),
                            end_Flag = "true",
                            CreateDate = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
                        };
                        //Json轉字符串
                        string mes0 = JsonConvert.SerializeObject(ES0);
                        //if(lineID=="219")
                            //Console.WriteLine(mes0);
                        //消息队列路径
                        MessageQueue queuees0;
                        queuees0 = new MessageQueue(pathes);
                        System.Messaging.Message msges0 = new System.Messaging.Message();
                        msges0.Body = mes0;
                        //發送消息
                        queuees0.Send(msges0);
                        isend = false;
                        sTimeList[i] = DateTime.Now;
                    }   
                                    
                    //默認發送end_Flag =false
                    FACT_EquipStop ES = new FACT_EquipStop()
                    {
                        Equip_ID = equipID,
                        Line_ID = lineID,
                        Status = machineStatusk,
                        start_time = sTimeList[i].ToString("yyyy/MM/dd HH:mm:ss"),
                        end_time = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"),
                        Time_length = (DateTime.Now - sTimeList[i]).TotalSeconds.ToString(),
                        end_Flag = "false",
                        CreateDate = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
                    };
                    
                    string mes = JsonConvert.SerializeObject(ES);
                    //if (lineID == "219")
                    //Console.WriteLine(mes);

                    MessageQueue queuees;
                    //實現消息队列
                    queuees = new MessageQueue(pathes);
                    System.Messaging.Message msges = new System.Messaging.Message();
                    msges.Body = mes;
                    //msgeo.Formatter = new XmlMessageFormatter(new Type[] { typeof(string) });
                    //發送消息
                    
                    queuees.Send(msges);
                    
                    //queuees.Purge();
                    //queuees.Close();
                    //              

                    lastMachineStatuslist[i] = machineStatusk;
                    i++;

                    //----------------------------------------------

                    //--------FACT_LineStatus
                    //FACT_LineStatus LS = new FACT_LineStatus()
                    //{
                    //    Line_ID = lineID,
                    //    Status = machineStatusk,
                    //    CreateDate = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
                    //};
                    //string mls = JsonConvert.SerializeObject(LS);

                    ////消息队列路径
                    //string pathls = @"FormatName:Direct=TCP:10.97.3.88\private$\linestatusdata";
                    string pathls = @"FormatName:Direct=TCP:10.196.171.27\private$\linestatusdata";
                    //MessageQueue queuels;
                    ////若是存在指定路径的消息队列 
                    ////if (MessageQueue.Exists(pathls))
                    ////{
                    ////    //获取这个消息队列
                    //queuels = new MessageQueue(pathls);
                    ////}
                    ////else
                    ////{
                    ////不存在，就建立一个新的，并获取这个消息队列对象
                    ////queuels = MessageQueue.Create(pathls);
                    ////}
                    //System.Messaging.Message msgls = new System.Messaging.Message();
                    //msgls.Body = mls;
                    ////msgeo.Formatter = new XmlMessageFormatter(new Type[] { typeof(string) });
                    //queuels.Send(msgls);

                    ////queuels.Purge();
                    ////queuels.Close();

                    //
                    //---------            
                }
                Console.WriteLine("EquipStop send");
                sconn.Dispose();
                sconn.Close();
                sconnsb.Clear();
                Thread.Sleep(30000);//设定時間間隔
            }
        }
    }
    public class FACT_EquipStop
    {
        public string Equip_ID { get; set; }     //設備ID
        public string Line_ID { get; set; }      //線體ID
        public string Status { get; set; }       //纖體狀態
        public string start_time { get; set; }   //開始時間
        public string end_time { get; set; }     //結束時間
        public string end_Flag { get; set; }     //結束標誌
        public string Time_length { get; set; }  //持續時間
        public string CreateDate { get; set; }   //發生時間
    }
    //public class FACT_LineStatus        //線體狀態
    //{
    //    public string Line_ID { get; set; }
    //    public string Status { get; set; }
    //    public string CreateDate { get; set; }
    //}
}
