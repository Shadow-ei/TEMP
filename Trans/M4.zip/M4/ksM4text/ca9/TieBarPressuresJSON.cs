﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using RabbitMQ;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using Newtonsoft;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json.Converters;
using System.Threading;

namespace ca9
{

    //=========================================哥林柱壓力傳輸   暫未使用
    class TieBarPressuresJSON
    {
        public Int32 IDcount = 0; //累計不重複發送數據標誌
        public void sendTieBarPressures()
        {
            while (true)
            {
                //數據庫連接
                SqlConnectionStringBuilder sconnsb = new SqlConnectionStringBuilder();
                sconnsb.DataSource = DataBase.DataSource;
                sconnsb.InitialCatalog = DataBase.InitialCatalog;
                sconnsb.UserID = DataBase.UserID;
                sconnsb.Password = DataBase.Password;
                sconnsb.MultipleActiveResultSets = true;
                SqlConnection sconn = new SqlConnection(sconnsb.ToString());

                try
                {
                    sconn.Open(); //打開數據庫
                    SqlCommand scomm2 = new SqlCommand();
                    //獲取哥林柱壓力數據
                    scomm2.CommandText = "select top 24 a.*,b.* from Tie_Bars_Pressure_Data a left join (select [MACHINE_ID],[TIE_BAR_P_ID] from BASIC_INFORMATION) b on a.Address = b.TIE_BAR_P_ID where a.ID >= '" + IDcount + "' order by ID desc ";
                    scomm2.Connection = sconn;
                    SqlDataReader sdreader2 = scomm2.ExecuteReader();
                    while (sdreader2.Read())
                    {
                        if (sdreader2["TIE_BAR_P_ID"].ToString() == "  ")
                        {
                            //Console.WriteLine("暫無有效數據！");
                        }
                        else
                        {
                            IDcount = sdreader2.GetInt32(0) + 24;
                            TieBarPressures tbp = new TieBarPressures()
                            {
                                SCADA_ID = sdreader2["MACHINE_ID"].ToString(),
                                DATE_TIME = sdreader2["DateTime"].ToString(),
                                TieBarPressure_A = sdreader2["TieBarPressure_A"].ToString(),
                                TieBarPressure_B = sdreader2["TieBarPressure_B"].ToString(),
                                TieBarPressure_C = sdreader2["TieBarPressure_C"].ToString(),
                                TieBarPressure_D = sdreader2["TieBarPressure_D"].ToString(),
                                SEND_TIME = DateTime.Now.ToString("yyyyMMddHHmmss")
                            };
                            TieBar tiebarjson = new TieBar()
                            {
                                MACHINE_TYPE = "tiebar",
                                MESSAGE = tbp
                            };
                            //jason轉為字符串
                            string wmessage = JsonConvert.SerializeObject(tiebarjson);
                            ///**
                            // * 创建连接连接到RabbitMQ
                            // */
                            //ConnectionFactory factory = new ConnectionFactory();
                            //设置MabbitMQ所在主机ip或者主机名
                           // factory.HostName = RabbitServer.HostName;
                           // factory.Port = RabbitServer.Port;
                           // factory.UserName = RabbitServer.UserName;
                           // factory.Password = RabbitServer.Password;
                            //创建一个连接
                           // IConnection connection = factory.CreateConnection();
                            //创建一个频道
                          //  IModel channel = connection.CreateModel();
                            //指定一个队列
                          //  channel.QueueDeclare(queue: "molding_cloud.tiebarpressures",
                                   //  durable: true,
                                   //  exclusive: false,
                                  //   autoDelete: false,
                                  //   arguments: null);
                            //发送的消息
                          //  var wbody = Encoding.UTF8.GetBytes(wmessage);
                            //往队列中发出一条消息
                         //   channel.BasicPublish(exchange: "",
                                                // routingKey: "molding_cloud.tiebarpressures",
                                                // basicProperties: null,
                                               //  body: wbody);
                          //  channel.Dispose();
                           // channel.Close();
                           // connection.Dispose();                      
                        }
                    }
                    Console.WriteLine("tiebar" + IDcount.ToString());
                    sdreader2.Close();
                    scomm2.Dispose();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
                finally
                {
                    sconn.Dispose();
                    sconn.Close();
                    sconnsb.Clear();
                    Thread.Sleep(400);//设定時間間隔
                }
            }
        }
        public class TieBar
        {
            public string MACHINE_TYPE { get; set; }
            public TieBarPressures MESSAGE { get; set; }
        }
        public class TieBarPressures
        {
            public string SCADA_ID { get; set; } //哥林柱壓力設備ID
            public string DATE_TIME { get; set; }//數據採集時間
            public string TieBarPressure_A { get; set; } //sensorA值
            public string TieBarPressure_B { get; set; } //sensorB值
            public string TieBarPressure_C { get; set; } //sensorC值
            public string TieBarPressure_D { get; set; } //sensorD值
            public string SEND_TIME { get; set; } //數據發送時間
        }
    }
}
