﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using RabbitMQ;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using Newtonsoft;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json.Converters;
using System.Threading;

namespace ca9
{
    //==============================溫度採集儀數據---------暫未使用
    class TemperaturesJSON
    {
        public Int32 IDcount = 0; //累計不重複發送數據標誌
        public void sendTemperatures()
        {
            while (true)
            {

                //數據庫連接
                SqlConnectionStringBuilder sconnsb = new SqlConnectionStringBuilder();
                sconnsb.DataSource = DataBase.DataSource;
                sconnsb.InitialCatalog = DataBase.InitialCatalog;
                sconnsb.UserID = DataBase.UserID;
                sconnsb.Password = DataBase.Password;
                sconnsb.MultipleActiveResultSets = true;
                SqlConnection sconn = new SqlConnection(sconnsb.ToString());
                try
                {
                    sconn.Open(); //打開數據庫
                    SqlCommand scomm3 = new SqlCommand();

                    //獲取溫度數據
                    scomm3.CommandText = "SELECT top 24 [ID] ,[Address] ,[DateTime] ,[Channel0],[Channel1],[Channel2],[Channel3],[Channel4] ,[Channel5],[Channel6] ,[Channel7],[Channel8],[Channel9] FROM [M4_DATABASE].[dbo].[Peripheral_Equipment_Temperature_Data] where ID >= '" + IDcount + "' order by ID desc ";
                    scomm3.Connection = sconn;
                    SqlDataReader sdreader3 = scomm3.ExecuteReader();
                    while (sdreader3.Read())
                    {
                        IDcount = sdreader3.GetInt32(0)+24;
                        Temperatures ttt = new Temperatures()
                        {
                            ADDRESS = sdreader3["Address"].ToString(),
                            DATE_TIME = sdreader3["DateTime"].ToString(),
                            Channel0 = sdreader3["Channel0"].ToString(),
                            Channel1 = sdreader3["Channel1"].ToString(),
                            Channel2 = sdreader3["Channel2"].ToString(),
                            Channel3 = sdreader3["Channel3"].ToString(),
                            Channel4 = sdreader3["Channel4"].ToString(),
                            Channel5 = sdreader3["Channel5"].ToString(),
                            Channel6 = sdreader3["Channel6"].ToString(),
                            Channel7 = sdreader3["Channel7"].ToString(),
                            Channel8 = sdreader3["Channel8"].ToString(),
                            Channel9 = sdreader3["Channel9"].ToString(),
                            SEND_TIME =  DateTime.Now.ToString("yyyyMMddHHmmss")
                        };
                        TemeratureCollector temeraturecollectorjson = new TemeratureCollector()
                        {
                            MACHINE_TYPE = "temeraturecollector",
                            MESSAGE = ttt
                        };
                        //json轉為字符串
                        string wmessage = JsonConvert.SerializeObject(temeraturecollectorjson);
                        ///**
                        // * 创建连接连接到MabbitMQ
                        // */
                        //ConnectionFactory factory = new ConnectionFactory();
                        //设置MabbitMQ所在主机ip或者主机名
                       // factory.HostName = RabbitServer.HostName;
                      //  factory.Port = RabbitServer.Port;
                       // factory.UserName = RabbitServer.UserName;
                      //  factory.Password = RabbitServer.Password;
                        //创建一个连接
                       // IConnection connection = factory.CreateConnection();
                        //创建一个频道
                       // IModel channel = connection.CreateModel();
                        //指定一个队列
                       // channel.QueueDeclare(queue: "molding_cloud.temperatures",
                               //  durable: true,
                               //  exclusive: false,
                               //  autoDelete: false,
                                // arguments: null);
                        //发送的消息
                       // var wbody = Encoding.UTF8.GetBytes(wmessage);
                        //往队列中发出一条消息
                        //channel.BasicPublish(exchange: "",
                                          //   routingKey: "molding_cloud.temperatures",
                                           //  basicProperties: null,
                                            // body: wbody);
                       // channel.Dispose();
                      //  channel.Close();
                      //  connection.Dispose();
                    }
                    Console.WriteLine("temperaturecollector" + IDcount.ToString());
                    sdreader3.Close();
                    scomm3.Dispose();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
                finally
                {
                    sconn.Dispose();
                    sconn.Close();
                    sconnsb.Clear();
                    Thread.Sleep(5000);//设定時間間隔
                }
            }
        }
        public class TemeratureCollector
        {
            public string MACHINE_TYPE { get; set; }
            public Temperatures MESSAGE { get; set; }
        }
        public class Temperatures
        {
            public string ADDRESS { get; set; }     //溫度採集儀ID
            public string DATE_TIME { get; set; }   //數據獲取時間
            public string Channel0 { get; set; }    //通道0數據
            public string Channel1 { get; set; }    //通道1數據
            public string Channel2 { get; set; }    //通道2數據
            public string Channel3 { get; set; }    //通道3數據
            public string Channel4 { get; set; }    //通道4數據
            public string Channel5 { get; set; }    //通道5數據
            public string Channel6 { get; set; }    //通道6數據
            public string Channel7 { get; set; }    //通道7數據
            public string Channel8 { get; set; }    //通道8數據
            public string Channel9 { get; set; }    //通道9數據
            public string SEND_TIME { get; set; }   //發送時間
        }
    }
}
