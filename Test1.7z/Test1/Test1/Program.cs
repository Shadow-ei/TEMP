﻿using System;
using System.Collections.Generic;
using System.Text;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;
using System.Data.SqlClient;

namespace Test1
{
    class Program
    {
        static void client_MqttMsgPublishReceived(object sender, MqttMsgPublishEventArgs e)
        {
            // 打印从订阅的Topic发布端收到的消息
            Console.WriteLine(string.Format("subscriber,topic:{0},content:{1}", e.Topic, Encoding.UTF8.GetString(e.Message)));
        }
        static void Main(string[] args)
        {
            List<string> topicList = new List<string>();
            List<byte> qosList = new List<byte>();
            
            SqlConnection sconn = new SqlConnection("Server=10.97.3.90; Database=M4_DATABASE; Uid=sa; Pwd=fea@123456");
            try
            {
                sconn.Open();
                string sql = "SELECT DISTINCT Line_ID FROM [BASIC_INFORMATION] WHERE Line_ID !='NULL'";
                SqlCommand scmd = new SqlCommand(sql, sconn);
                SqlDataReader sdr = scmd.ExecuteReader();
                while (sdr.Read())
                {
                    topicList.Add("/orderdata/" + sdr["Line_ID"].ToString().Substring(3, 4));
                    qosList.Add(2);
                }
                sdr.Close();
                scmd.Dispose();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                sconn.Dispose();
                sconn.Close();
            }
            //string clientId = Guid.NewGuid().ToString();//a52cd84d-16ad-4586-8cca-b6e27ab8d93e
            // 实例化Mqtt客户端 
            MqttClient client = new MqttClient("10.98.5.76", 7020, false, null, null, MqttSslProtocols.TLSv1_2);
            // 注册接收消息事件 
            client.MqttMsgPublishReceived += client_MqttMsgPublishReceived;
            client.Connect("FX_Client");
            // 订阅主题 "/orderdata/"， 订阅质量 QoS 2 
            //client.Subscribe(new string[] { "/orderdata/" }, new byte[] { MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE });
            client.Subscribe(topicList.ToArray(), qosList.ToArray());
        }
    }
}
