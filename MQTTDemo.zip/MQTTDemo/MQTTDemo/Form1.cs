﻿using MQTTnet;
using MQTTnet.Client;
using MQTTnet.Client.Connecting;
using MQTTnet.Client.Disconnecting;
using MQTTnet.Client.Options;
using MQTTnet.Client.Receiving;
using MQTTnet.Extensions.ManagedClient;
using MQTTnet.Formatter;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MQTTDemo
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();


        }

        private MqttClientOptions options;

        private IManagedMqttClient mqttClient;



        private void OnSubscriberConnected(MqttClientConnectedEventArgs x)
        {
            AppendLogMsg("已连接到MQTT服务器！");
        }


        private void OnSubscriberDisconnected(MqttClientDisconnectedEventArgs x)
        {
            AppendLogMsg("已断开MQTT服务器连接！");
        }

        private void OnSubscriberMessageReceived(MqttApplicationMessageReceivedEventArgs x)
        {
            var payloadString = x.ApplicationMessage.ConvertPayloadToString();

            payloadString = ConvertJsonString(payloadString);

            var item = $"{Environment.NewLine}Topic: {x.ApplicationMessage.Topic}{Environment.NewLine}Payload: {payloadString} {Environment.NewLine}QoS: {x.ApplicationMessage.QualityOfServiceLevel}";
            this.BeginInvoke((MethodInvoker)delegate
            {
                AppendReceiveMsg(item);
            });
        }


        private async Task SubscriberStart()
        {

            var tcpServer = tbx_mqtt_server.Text;
            var tcpPort = int.Parse(tbx_mqtt_port.Text.Trim());
            var mqttUser = tbx_user_name.Text.Trim();
            var mqttPassword = tbx_pwd.Text.Trim();

            var mqttFactory = new MqttFactory();



            this.options = new MqttClientOptions
            {
                ClientId = "ClientSubscriber",
                ProtocolVersion = MqttProtocolVersion.V311,
                ChannelOptions = new MqttClientTcpOptions
                {
                    Server = tcpServer,
                    Port = tcpPort
                }
            };
            if (options.ChannelOptions == null)
            {
                throw new InvalidOperationException();
            }

            if(!string.IsNullOrEmpty(mqttUser))
            {
                options.Credentials = new MqttClientCredentials
                {
                    Username = mqttUser,
                    Password = Encoding.UTF8.GetBytes(mqttPassword)
                };
            }

            options.CleanSession = true;
            options.KeepAlivePeriod = TimeSpan.FromSeconds(5);

            this.mqttClient = mqttFactory.CreateManagedMqttClient();
            this.mqttClient.ConnectedHandler = new MqttClientConnectedHandlerDelegate(OnSubscriberConnected);
            this.mqttClient.DisconnectedHandler = new MqttClientDisconnectedHandlerDelegate(OnSubscriberDisconnected);
            this.mqttClient.ApplicationMessageReceivedHandler = new MqttApplicationMessageReceivedHandlerDelegate(OnSubscriberMessageReceived);
            await this.mqttClient.StartAsync(
                new ManagedMqttClientOptions
                {
                    ClientOptions = options
                });
        }

        private async void btn_connect_Click(object sender, EventArgs e)
        {
            if (this.mqttClient == null)
            {
                await SubscriberStart();
                btn_subscribe_Click(null, null);

            }
            btn_subscribe.Enabled = true;
            btn_cancel_subscribe.Enabled = true;
            btn_send_msg.Enabled = true;
            btn_connect.Enabled = false;
            btn_disconnect.Enabled = true;

        }

        private async void btn_subscribe_Click(object sender, EventArgs e)
        {

            var topicFilter = new MqttTopicFilter { Topic = this.tbx_subscribe_topic.Text.Trim() };
            await this.mqttClient.SubscribeAsync(topicFilter);
            AppendLogMsg($"订阅到Topic：{ this.tbx_subscribe_topic.Text.Trim()}！");


        }

        private async void btn_send_msg_Click(object sender, EventArgs e)
        {
            var publish_topic = tbx_publish_topic.Text.Trim();
            var publish_msg = tbx_send_msg.Text;
            var message = new MqttApplicationMessageBuilder()
            .WithTopic(publish_topic)
            .WithPayload(publish_msg)
            .WithExactlyOnceQoS()
            .Build();

            if (this.mqttClient != null)
            {
                await this.mqttClient.PublishAsync(message);
            }
        }

        private async void btn_disconnect_Click(object sender, EventArgs e)
        {
            if (this.mqttClient == null)
            {
                return;
            }

            await this.mqttClient.StopAsync();
            this.mqttClient = null;
            btn_connect.Enabled = true;
            btn_disconnect.Enabled = false;
            btn_subscribe.Enabled = false;
            btn_cancel_subscribe.Enabled = false;
            btn_send_msg.Enabled = false;

        }

        private void AppendReceiveMsg(string msg)
        {
            Invoke((new Action(() =>
            {
                tbx_receive_msg.AppendText(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss: ") + msg + Environment.NewLine + Environment.NewLine);
            })));
        }
        private void AppendSendMsg(string msg)
        {
            Invoke((new Action(() =>
            {
                tbx_send_msg.AppendText(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss: ")+msg + Environment.NewLine);
            })));
        }

        private void AppendLogMsg(string msg)
        {
            Invoke((new Action(() =>
            {
                tbx_log.AppendText(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss: ") + msg + Environment.NewLine);
            })));
        }

        private string ConvertJsonString(string str)
        {
            try
            {
                //格式化json字符串
                JsonSerializer serializer = new JsonSerializer();
                TextReader tr = new StringReader(str);
                JsonTextReader jtr = new JsonTextReader(tr);
                object obj = serializer.Deserialize(jtr);
                if (obj != null)
                {
                    StringWriter textWriter = new StringWriter();
                    JsonTextWriter jsonWriter = new JsonTextWriter(textWriter)
                    {
                        Formatting = Formatting.Indented,
                        Indentation = 4,
                        IndentChar = ' '
                    };
                    serializer.Serialize(jsonWriter, obj);
                    return textWriter.ToString();
                }

                return str;
            }
            catch (Exception ex)
            {
                return str;
            }
        }

        private async void btn_cancel_subscribe_Click(object sender, EventArgs e)
        {
            string[] topics = { this.tbx_subscribe_topic.Text.Trim() };
            await this.mqttClient.UnsubscribeAsync(topics);
            AppendLogMsg($"已取消订阅Topic：{ this.tbx_subscribe_topic.Text.Trim()}！");
        }

        private void btn_clear_receive_Click(object sender, EventArgs e)
        {
            tbx_receive_msg.Clear();
        }
    }
}
